import { useState, useEffect } from 'react'
import axios from 'axios'
export default function LoginForm(props) {
    const [username, setUsername] = useState('')
    const [password, setPassword] = useState('')
    const [token, setToken] = useState('');
    const [msg, setMsg] = useState('')
    const [isAuth, setIsAuth] = useState(false)

    let today = new Date();

    let date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();

    // let time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    useEffect(() => {
        localStorage.setItem('token', token);

    }, [token])


    const handleSubmit = async (e) => {
        e.preventDefault();


        try {
            const response = await axios.post('https://chmbc.nehetek.com/auth/register', { username: username, password: password });
            setToken(response.data.result.token)


            setMsg(response.data.result.msg)

            console.log(response.data.result);
            setIsAuth(true)
        } catch (error) {
            console.error(error)
        }




    }


    if (isAuth) {
        return (

            <div>
                <Ballot date={date} token={token} />
            </div>

        )
    }
    else {
        return (
            <div className="text-center">

                <Alert msg={msg} />
                <form className="form-signin" onSubmit={handleSubmit}>
                    <h1 className="h3 mb-3 font-weight-normal">Please sign in</h1>
                    <label htmlFor="inputUsername" className="sr-only">Member ID</label>
                    <input type="text" id="inputUsername" name="username" value={username} onChange={e => setUsername(e.target.value)} className="form-control" placeholder="Member ID" required autoFocus />
                    <label htmlFor="inputPassword" className="sr-only">Password</label>
                    <input type="password" id="inputPassword" name="password" value={password} onChange={e => setPassword(e.target.value)} className="form-control" placeholder="Password" required />

                    <button className="btn btn-lg btn-primary btn-block" type="submit" >Sign in</button>
                    <p className="mt-5 mb-3 text-muted">&copy; 2021</p>
                </form>

            </div>

        )
    }
}


function Alert(props) {

    if (props.msg) {
        return (
            <div className="alert alert-warning" role="alert">
                {props.msg}
            </div>
        )
    } else {
        return (
            <></>
        )
    }
}


function Ballot(props) {


    let url = 'https://chmbc.nehetek.com/ballot/create'


    const handleAccept = async (e) => {
        e.preventDefault()
        console.log(props.token);

        // let response = {
        //     election_id: 1,
        //     candidate_id: 1,
        //     ballot_response: 'ACCEPT'

        // }
        try {

            const response = await axios.post(url, {
                election_id: 1,
                candidate_id: 1,
                ballot_response: 'ACCEPT'
            }
                , {
                    headers: { 'Authorization': `Bearer ${props.token}` }
                })


            alert('Thank you for voting.')
            console.log(response);
        } catch (error) {
            alert("Duplicates not allowed")
        }



    }


    const handleDoNotAccept = async (e) => {
        e.preventDefault()

        try {

            const response = await axios.post(url, {
                election_id: 1,
                candidate_id: 1,
                ballot_response: 'DO NOT ACCEPT'
            }
                , {
                    headers: { 'Authorization': `Bearer ${props.token}` }
                })


            alert('Thank you for voting.')
            console.log(response);
        } catch (error) {
            alert("Duplicates not allowed!")
        }





        console.log(props.token);
    }

    return (
        <div className="card">
            <h5 className="card-header text-center">Ballot ({props.date})</h5>
            <div className="card-body">

                <div className="card-body">
                    <p className="card-text">
                        <i>   The Pastor Search Committee recommends the following candidate for the Office of Pastor:The Pastor Search Committee recommends the following candidate for the Office of Pastor:A Pastor shall be elected by the Church membership when the vacancy occurs. The election shall take place at a meeting called especially for that purpose. One week’s public notice shall be given. Voting shall be by ballot. (ARTICLE II Section 1 Clause C – College Hill Constitution and By-Laws)
                 </i></p>
                    <p className="card-text"><strong>
                        The Pastor Search Committee recommends the following candidate for the Office of Pastor:</strong>
                    </p>
                    <h5 className="card-text center">
                        Reverend Chauncy L. Jordan, Sr.

</h5>
                </div>
                <form onSubmit={handleAccept}>
                    <input type="hidden" name="reponse " value="ACCEPT" />
                    <button type="submit" className="btn btn-primary btn-lg btn-block">I ACCEPT    </button>

                </form>
                <form onSubmit={handleDoNotAccept}>
                    <input type="hidden" name="reponse2 " value="DO NOT ACCEPT" />
                    <button type="submit" className="btn btn-secondary btn-lg btn-block">I DO NOT ACCEPT    </button>

                </form>

                <p className="m-3 card-text">the Recommendation of the Pastor Search Committee.</p>


            </div>
        </div>
    )
}