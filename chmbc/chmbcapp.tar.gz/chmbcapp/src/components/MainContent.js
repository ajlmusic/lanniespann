export default function MainContainer(props) {
    return (
        <div className="col-sm-9">
            {props.children}
        </div>
    )
}