function SideNav(props) {
    return (
        <div className="col-sm-3 sidenav">
            {props.children}
        </div>
    )
}