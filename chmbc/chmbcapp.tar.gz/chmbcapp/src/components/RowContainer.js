export default function RowContainer(props) {
    return (
        <div className="row content">
            {props.children}
        </div>
    )
}