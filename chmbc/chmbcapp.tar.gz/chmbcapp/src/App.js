import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import LoginForm from './components/LoginForm'

function App() {
  return (

    <div className="container-fluid">
      <div className="text-center">
        <h3>CHMBC Ballot</h3>
      </div>
      <LoginForm />
    </div>
  );
}

export default App;
