export interface BallotPayload {
    ballot_id: string,
    ballot_date: string,
    election_id: string,
    candidate_id: string,
    usr_id: string,
    ballot_response: string,
    
}

export interface PaperBallotPayload {
    ballot_id: string,
    ballot_date: string,
    election_id: string,
    candidate_id: string,
    paper_ballot_id: string,
    ballot_response: string,
    
}

export interface candidatePayload {
    id: number
    ballot_date: string,
    title: string,
    firstname: string,
    middlename: string,
    lastname: string,
    postion: string,
    bio: string,
    image_location: string
}

export interface QueryObj {
    text: string,
    values: Array<any>
}

export interface ElectionPayload {

    election_id: string,
    election_date: string,
    is_election_active: boolean,
    election_title: string,
    election_notes: string,

}
export interface AuthUserPayload {
    token: string,
        
}
export interface UserPayload {
    username: string,
    user_password: string
}


export interface AdminPayLoad {
    id: number,
    admin_uuid: string,
    username: string,
    password: string,
    acl: string
}

export interface RosterPayload {
    roster_id: string,
    userid: string,
    familyid: string,
    rosterkey: string,
    firstname: string,
    preferredname: string,
    lastname: string,
    formalfullname: string,
    birthday: string,
    age: string,
    gender: string,
    email: string,
    secondaryemail: string,
    homephone: string,
    cellphone: string,
    address: string,
    city: string,
    state: string,
    zipcode: string,
    chmbc: string,
}