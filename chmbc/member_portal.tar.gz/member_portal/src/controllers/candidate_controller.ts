import CandidateModel  from '../services/models/candidateModel';
import { Request, RequestParamHandler, Response } from 'express'
const candidateModel = new CandidateModel();


class CandidateController {

    fetchAll = async (req: Request, res: Response) => {
        const result = await candidateModel.fetchAll();
        res.json(result);

    }

    create = async (req: Request, res: Response) => {
        const result = await candidateModel.create(req.body);
        //console.log(req.body)
        res.json(result)


    }
    fetchOneById = async (req: Request, res: Response) => {
        const result = await candidateModel.fetchOneById(Number(req.params.id));
        res.json(result);

    }
    updateOneById = async (req: Request, res: Response) => {
        
        // if (req.body.id == " ") {
        //     res.sendStatus(204).json({ msg: 'Data missing' })
        // }

        console.log(req.body);
        
        const result = await candidateModel.updateOneById(req.body);
        res.json(result);

    }
    delete = async (req: Request, res: Response) => {
        const result = await candidateModel.delete(Number(req.params.id));
        res.json(result);

    }

}
export default new CandidateController();