import AuthModel from '../services/models/authModel';
import { Request, RequestParamHandler, Response, ErrorRequestHandler } from 'express'
import { QueryResultBase } from 'pg'
import jwt from 'jsonwebtoken'
const authModel = new AuthModel();
import { UserPayload } from '../types'


class AdminController {
    count: number = 0;
    isValidLogin: boolean;

    constructor() {
        this.isValidLogin = false;
    }
    async fetchAll(req: Request, res: Response) { }
    async fetchOneById(req: Request, res: Response) { }
    async updateOneById(req: Request, res: Response) { }

    async delete(req: Request, res: Response) { }

    async verifyAudit(req: any, res: any) {

    }

    async register(req: Request, res: Response) {
        let userIsRegistered:any;
        let result;
        //let memberExistInRoster;

        //memberExistInRoster = await authModel.checkRoster(req.body);

        userIsRegistered = await authModel.checkUser(req.body);

        try {


            if (userIsRegistered.rowCount !== 0) {
                // res.json('user already registered')
                result = await authModel.login(req.body)
                res.json({ result });
            } else {

                result = await authModel.register(req.body)
                res.json({ result });
            }

        }
        catch (error) {
            res.status(500).json({
                status: 'error',
                code: error.code,
                message: (error.code == 23505) ? 'User already authenticated!' : error.message,
                statusCode: 500
            });
        }

    }




    async login(req: Request, res: Response) {

        let result;

        try {
            result = await authModel.adminLogin(req.body);
            res.json({ result })
        } catch (error) {
            res.status(404).json({
                status: 'error',
                code: error.code,
                message: (error.code == 23505) ? 'User already authenticated!' : error.message,
                statusCode: 404
            });
        }


    }




    async logout(req: Request, res: Response) {
        let result;
        try {
            result = await authModel.logout(req.body);
            res.json({ result })

        } catch (error) {
            throw error;
        }
    }

}

export default new AdminController();