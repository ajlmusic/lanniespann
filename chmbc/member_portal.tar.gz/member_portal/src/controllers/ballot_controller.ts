import BallotModel from '../services/models/ballotModel'
import { Errback, ErrorRequestHandler, Request, Response } from 'express'
import { QueryResult } from 'pg';
const ballotModel = new BallotModel();

class BallotController {
    async fetchAll(req: any, res: Response) {
        let result = await ballotModel.fetchAll();
        res.json(result)
    }
    fetchOneById() { }
    updateOneById() { }
    async addPaperBallot(req: any, res: Response) {
        let result;

        try {
            result = await ballotModel.addPaperBallot(req.body)
            res.json({ result })
        } catch (error) {
            res.status(403).json({
                status: 'error',
                code: error.code,
                message: (error.code == 23505) ? 'Ballot already submitted. Duplicates not allowed!' : error.message,
                statusCode: 403
            });
        }
    }

    async checkAudit(req: any, res: Response) {
        req.body.token = req.user;
        let result, result2;
        console.log(req.body);

        try {
            result = await ballotModel.checkAudit(req.body);
            if (result.rowCount !== 0) {
                // audit trail
                res.json({result })

            } else {
                console.log('DO WE EVER GET HERE?');
                
                result2 = await ballotModel.createPaperBallotAudit(req.body);
                res.json({result2 })
            }

        } catch (error) {
            // console.log('CATCHING ERROR FROM CONTROLLER: ',error)
            res.status(403).json({
                status: 'error',
                code: error.code,
                message: (error.code == 23505) ? 'Ballot already submitted. Duplicates not allowed!' : error.message,
                statusCode: 403
            });
        }

    }
    // async createPaperBallotAudit(req: any, res: Response) {
    //     let result;
    //     try {
    //         result = await ballotModel.createPaperBallotAudit(req.body);
    //         res.json({ msg: 'Paper Ballot logged', result })
    //     } catch (error) {
    //         res.status(403).json({
    //             status: 'error',
    //             code: error.code,
    //             message: error.message,
    //             statusCode: 403
    //         });
    //     }
    // }
    async create(req: any, res: Response) {
        req.body.usr_id = req.user;
        //console.log(req.body);

        let result;

        try {
            result = await ballotModel.auditBallot(req.body)
            
            console.log('check this out');
            
            
            if (result) {
                // audit trail
                await ballotModel.create(req.body);
            }
            res.json({ result })
        } catch (error) {
            // console.log('CATCHING ERROR FROM CONTROLLER: ',error)
            res.status(403).json({
                status: 'error',
                code: error.code,
                message: (error.code == 23505) ? 'Ballot already submitted. Duplicates not allowed!' : error.message,
                statusCode: 403
            });
        }
    }
    async delete(req: Request, res: Response) {
        let result = await ballotModel.delete(req.params.id);
        res.json({ result })
    }
}
export default new BallotController();