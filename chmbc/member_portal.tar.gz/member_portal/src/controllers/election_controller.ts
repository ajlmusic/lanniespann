import { ElectionModel } from '../services/models/electionModel';
import { Request, RequestParamHandler, Response } from 'express'
const electionModel = new ElectionModel();


class ElectionController {

    fetchAll = async (req: Request, res: Response) => {
        const result = await electionModel.fetchAll();
        res.json(result);

    }

    create = async (req: Request, res: Response) => {
        const result = await electionModel.create(req.body);
        //console.log(req.body)
        res.json(result)


    }
    fetchOneById = async (req: Request, res: Response) => {
        const result = await electionModel.fetchOneById(Number(req.params.id));
        res.json(result);

    }
    updateOneById = async (req: Request, res: Response) => {

        // if (req.body.id == " ") {
        //     res.sendStatus(204).json({ msg: 'Data missing' })
        // }

        console.log(req.body);

        const result = await electionModel.updateOneById(req.body);
        res.json(result);

    }
    delete = async (req: Request, res: Response) => {
        const result = await electionModel.delete(req.params.id);
        res.json(result);

    }

}
export default new ElectionController();