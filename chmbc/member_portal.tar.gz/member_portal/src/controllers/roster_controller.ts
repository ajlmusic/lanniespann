import RosterModel  from '../services/models/rosterModel';
import { Request, RequestParamHandler, Response } from 'express'
const rosterModel = new RosterModel();

class RosterController {
    async fetchAll(req: Request, res: Response) {

        const result = await rosterModel.fetchAll();
        res.json(result);

    }
    async fetchOneById(req: Request, res: Response) {
        
        
        const result = await rosterModel.fetchOneById(Number(req.params.id));
        res.json(result);
    }
    updateOneById(){}
    create(){}
    delete(){}
}
export default new RosterController();