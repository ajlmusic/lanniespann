import bcrypt from 'bcrypt';

class HashUser {
    username: string;
    password: string;
    saltRounds: number;
    hashUser: string;
    hashPass: string;

    constructor(username: string,password: string, saltRounds: number) {
        this.username = username;
        this.password = password;
        this.saltRounds = 10;
        this.hashUser = '';
        this.hashPass = '';
    }
    

    async generateHashUser(username: string, password: string) {
        this.hashUser = await bcrypt.hash(this.username, this.saltRounds)
        this.hashPass = await bcrypt.hash(this.password, this.saltRounds)
        return {hashUser: this.hashUser, hashPass: this.hashPass }
    }


}

export default HashUser;