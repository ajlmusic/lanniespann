export default function (err: Error, result: boolean) {
    if (err) {
        throw "oops... something went wrong";
    }
    return result;

}