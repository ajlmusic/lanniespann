import dotenv from 'dotenv'
dotenv.config();
import crypto from 'crypto';
import bcrypt from 'bcrypt';
import CheckPass from '../check_bcrypt_password';
import dao from '../pg'
import { UserPayload, AuthUserPayload, AdminPayLoad } from '../../types'
import { query } from 'winston';
import jwt from 'jsonwebtoken';

class AuthModel {
    secretKey: string;
    userExist: boolean;

    constructor() {
        this.secretKey = String(process.env.SECRET);
        this.userExist = false;
    }

    fetchAll() { }
    fetchOneById() { }
    updateOneById() { }

    //Encrpyted User Registratiion
    async checkRoster(userPayload: UserPayload) {
        let query = {
            text: "SELECT * FROM roster WHERE userid = $1 AND rosterkey = $2",
            values: [userPayload.username, userPayload.user_password]
        }
        let result;
        try {
            result = await dao(query);
            console.log('ROSTER CHECK: ', result)
            return result;

        } catch (error) {
            console.error(error)
        }
    }
    async checkUser(userPayload: UserPayload) {
        const cryptUser = crypto.createHash('sha256').update(String(userPayload.username)).digest('hex');
        //const cryptPass = crypto.createHash('sha256').update(String(userPayload.user_password)).digest('hex');
        let query = {
            text: "SELECT * FROM users WHERE username = $1",
            values: [cryptUser]
        }


        let result;
        try {
            result = await dao(query);
            console.log('USER CHECK: ', result)
            return result;

        } catch (error) {
            console.error(error)
        }
    }

    async register(userPayload: UserPayload) {
        // console.log(userPayload);
        const cryptUser = crypto.createHash('sha256').update(String(userPayload.username)).digest('hex');
        const cryptPass = crypto.createHash('sha256').update(String(userPayload.user_password)).digest('hex');
        // update registered status in roster
        let query2 = {
            text: "UPDATE TABLE roster SET isRegistered = $1 WHERE userid = $2",
            values: [true, userPayload.username]
        }

        let query = {
            text: "INSERT INTO users (username, user_password) VALUES($1, $2)",
            values: [cryptUser, cryptPass]
        }

        //access token
        let userExist
        let isRegistered;
        let result: any;

        try {


            result = await dao(query);
            // isRegistered = await dao(query2);


            return result;
        } catch (error) {
            return error
        }

    }

    delete() { }


    // ADMIN LOGIN 
    async adminLogin(adminPayload: AdminPayLoad) {
        // Find Admin User
        const cryptPass = crypto.createHash('sha256').update(String(adminPayload.password)).digest('hex');
        console.log(cryptPass);
        let query = {
            text: "SELECT * FROM admins WHERE username = $1 AND password = crypt($2, password) ",
            values: [adminPayload.username, adminPayload.password]
        }
        // const result = await dao(query);

        let result;

        try {

            result = await dao(query);
            if (result) {
                if (result.rowCount == 1) {
                    const authUser = {
                        msg: 'login success!',
                        token: jwt.sign({ a: result.rows[0].acl, id: result.rows[0].admin_uuid }, String(process.env.ACCESS_TOKEN_SECRET), { expiresIn: '8hr' })
                    }
                    let query1 = {
                        text: "INSERT INTO access_tokens (access_token, user_id) VALUES ($1, $2)",
                        values: [authUser.token, result.rows[0].admin_uuid]
                    }
                    let result2 = await dao(query1);


                    if (result2) {
                        if (result2.rowCount == 1) {
                            return authUser;
                        } else {
                            throw result2
                        }
                    }
                } else {
                    throw 'Admin not found'
                }





            }
            // temp
            return result;

        } catch (error) {
            throw error
        }




    }



    // LOGIN 
    async login(userPayload: UserPayload) {
        // Find User
        const cryptUser = crypto.createHash('sha256').update(String(userPayload.username)).digest('hex');
        //const cryptPass: string = await bcrypt.hash(String(userPayload.user_password), 10);
        const cryptPass = crypto.createHash('sha256').update(String(userPayload.user_password)).digest('hex');
        console.log(cryptUser);
        console.log(cryptPass);
        let query = {
            text: "SELECT * FROM users WHERE username = $1 AND user_password = $2 ",
            values: [cryptUser, cryptPass]
        }
        // const result = await dao(query);

        let result;

        try {

            result = await dao(query);
            if (result) {
                if (result.rowCount == 1) {
                    const authUser = {
                        msg: 'login success!',
                        token: jwt.sign({ m: userPayload.username, u: result.rows[0].user_uuid }, String(process.env.ACCESS_TOKEN_SECRET), { expiresIn: '1hr' })
                    }
                    let query1 = {
                        text: "INSERT INTO access_tokens (access_token, user_id) VALUES ($1, $2)",
                        values: [authUser.token, result.rows[0].user_uuid]
                    }
                    let result2 = await dao(query1);
                    if (result2) {
                        if (result2.rowCount == 1) {
                            return authUser;
                        } else {
                            throw result2
                        }
                    }
                } else {
                    throw 'User not found'
                }





            }
            // temp
            return result;

        } catch (error) {
            throw error
        }




    }
    async logout(authUserPayload: AuthUserPayload) {
        // const cryptUser = crypto.createHash('sha256').update(String(userPayload.username)).digest('hex');
        try {
            let query = {
                text: "DELETE FROM access_tokens WHERE access_token = $1",
                values: [authUserPayload.token]
            }
            let result = await dao(query);

            return result;
        } catch (error) {
            throw error
        }
    }
}

export default AuthModel;