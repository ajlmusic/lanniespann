import dao from '../pg'

import { ElectionPayload } from '../../types'

class ElectionModel {

    async fetchAll() {
        let query = { text: "SELECT * FROM elections", values: [] };

        const rows = await dao(query)
        console.log(rows);


        return rows;
    }

    async create(electionPayload: ElectionPayload) {
        let query = {
            text: "INSERT INTO elections (  election_date,\
                is_election_active, election_title,election_notes) VALUES($1, $2, $3, $4) \
                RETURNING election_id, election_date, is_election_active, election_title, election_notes",
                
            values: Object.values(electionPayload)

        }
        
        const rows = await dao(query);

        return rows;

    }

    async fetchOneById(id: number) {
        let query = {
            text: "SELECT * FROM elections WHERE election_id = $1",
            values: [id]
        }
        const rows = await dao(query)
        console.log(rows);

        return rows;
    }

    async updateOneById(electionPayload: ElectionPayload) {
        let query = {
            text: "UPDATE elecitons SET election_date = $2, is_election_active = $3, election_title = $4, \
                    election_title = $5, election_notes = $6, \
                    WHERE election_id = $1 RETURNING *",
            values: Object.values(electionPayload)

        }
        console.log('QUERY Obj: ', query);

        const rows = await dao(query)
        console.log(rows);


        return rows;
    }

    delete(id: string) {
        let query = {
            text: "DELETE FROM elections WHERE election_id = $1 \
                    RETURNING *",
            values: [id]
        }
        return dao(query);
    }

}

export { ElectionModel }