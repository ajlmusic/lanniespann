import dao from '../pg';
import {RosterPayload } from '../../types';

class RosterModel {
    async fetchAll() {
        let query = { text: "SELECT * FROM roster", values: [] };

        const rows = await dao(query)
        console.log(rows);

        return rows;
    }
   async fetchOneById(id: any ) {

        let query = {
            text: "SELECT * FROM roster WHERE userid = $1",
            values: [id]
        }
        console.log(query)
        const rows = await dao(query)
        console.log(rows);

        return rows;

    }
    updateOneById(){}
    create(){}
    delete(){}
}

export default RosterModel;