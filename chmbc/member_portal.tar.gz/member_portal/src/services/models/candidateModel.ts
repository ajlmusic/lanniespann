import dao from '../pg'

import { candidatePayload } from '../../types'

class CandidateModel {

    async fetchAll() {
        let query = { text: "SELECT * FROM candidate", values: [] };

        const rows = await dao(query)
        console.log(rows);


        return rows;
    }

    async create(candidatePayload: candidatePayload) {
        let query = {
            text: "INSERT INTO candidate (ballot_date, title, \
                firstname, middlename, lastname, \
                position, bio, image_location) VALUES($1, $2, $3, $4, $5, $6, $7, $8) \
                RETURNING candidate_id, ballot_date, title, \
                firstname, middlename, lastname, bio, image_location",
                
            values: Object.values(candidatePayload)

        }
        
        const rows = await dao(query);

        return rows;

    }

    async fetchOneById(id: number) {
        let query = {
            text: "SELECT * FROM candidate WHERE candidate_id = $1",
            values: [id]
        }
        const rows = await dao(query)
        console.log(rows);

        return rows;
    }

    async updateOneById(candidatePayload: candidatePayload) {
        let query = {
            text: "UPDATE candidate SET ballot_date = $2, title = $3, firstname = $4, \
                    middlename = $5, lastname = $6, \
                    position = $7, bio = $8, image_location = $9 \
                    WHERE candidate_id = $1 \
                    RETURNING candidate_id, ballot_date, title, \
                    firstname, middlename, lastname, bio, image_location",
            values: Object.values(candidatePayload)

        }
        console.log('QUERY Obj: ', query);

        const rows = await dao(query)
        console.log(rows);


        return rows;
    }

    delete(id: number) {
        let query = {
            text: "DELETE FROM candidate WHERE candidate_id = $1 \
                    RETURNING *",
            values: [id]
        }
        return dao(query);
    }

}

export default CandidateModel;