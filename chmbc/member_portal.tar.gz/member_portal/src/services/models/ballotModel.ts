import { QueryResult } from 'pg';
import { BallotPayload, PaperBallotPayload } from '.././../types'
import dao from '../pg'
import jwt from 'jsonwebtoken'

class BallotModel {
    async fetchAll() {
        let query = { text: "SELECT * FROM e_ballot", values: [] };

        const result = await dao(query)
        return result;
    }
    fetchOneById() { }
    updateOneById() { }
    async addPaperBallot(paperBallotPayload: PaperBallotPayload) {

        let query, result;
        query = {
            text: 'INSERT INTO p_ballot (election_id, candidate_id, paper_ballot_id, ballot_response) VALUES($1,$2,$3,$4)',
            values: [paperBallotPayload.election_id, paperBallotPayload.candidate_id, paperBallotPayload.paper_ballot_id, paperBallotPayload.ballot_response]
        }
        try {
            result = await dao(query);
            return result;
        } catch (error) {
            throw error;
        }

    }
    async checkAudit(paperBallotPayload: any) {
        let query = {
            text: 'SELECT * FROM audit WHERE userid = $1',
            values: [paperBallotPayload.userid]
        }

        let result;

        try {
            result = await dao(query);
            if (result.rowCount >= 1) {
                return result
            } else {
                return result // { msg: 'No record located.' }
            }
        } catch (error) {
            throw error;
        }

    }
    async createPaperBallotAudit(paperBallotPayload: any) {
        let result;
        let query = {
            text: "INSERT INTO audit (election_id, userid, ballot_method) VALUES($1,$2,$3)",
            values: [paperBallotPayload.election_id, paperBallotPayload.userid, 'paper']
        }
        try {
            result = await dao(query);
            return result;
        } catch (error) {
            throw error
        }
    }

    async auditBallot(ballotPayload: any) {

        // let decodedToken;

        // jwt.verify(ballotPayload.usr_id,
        //     String(process.env.ACCESS_TOKEN_SECRET),
        //     (err, token: any) => {
        //         decodedToken = token.m;
        //     })

        let query = {
            text: "INSERT INTO audit \
                (election_id, userid, ballot_method) \
                VALUES ($1,$2,$3)",
            values: [
                ballotPayload.election_id,
                ballotPayload.usr_id.m,
                'electronic'
            ]
        }
        let result;
        try {
            result = await dao(query);
            return result;

        } catch (error) {
            throw error;
        }

    }
    async create(ballotPayload: any) {
        //console.log(ballotPayload);

        // let decodedToken;

        // jwt.verify(ballotPayload.usr_id,
        //     String(process.env.ACCESS_TOKEN_SECRET),
        //     (err, token: any) => {
        //         decodedToken = token.u;
        //     })

        let query = {
            text: "INSERT INTO e_ballot \
            (election_id, candidate_id, usr_id, ballot_response) \
            VALUES ($1,$2,$3,$4)",
            values: [
                ballotPayload.election_id,
                ballotPayload.candidate_id,
                ballotPayload.usr_id.u,
                ballotPayload.ballot_response
            ]
        }
        let result;
        try {
            result = await dao(query);
            return result;

        } catch (error) {
            throw error;
        }

    }
    async delete(id: string) {
        let query = {
            text: "DELETE FROM e_ballot WHERE ballot_id = $1 \
                    RETURNING *",
            values: [id]
        }

        let result: QueryResult;
        try {
            result = await dao(query);
            return result;

        } catch (error) {
            console.error(error)
        }
    }
}

export default BallotModel;