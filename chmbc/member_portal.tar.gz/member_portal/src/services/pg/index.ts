import dotenv from 'dotenv';
dotenv.config();

import { Pool, QueryConfig, QueryResult } from 'pg';
import { QueryObj } from '../../types';

const {
    DB_HOST, DB_NAME, DB_USER, DB_PWD, DB_PORT
} = process.env;

type PgReponse = {
    (response: object): object;
}

function cb(response: object) {
    return response;
}
const pool = new Pool(
    {
        user: DB_USER,
        host: DB_HOST,
        database: DB_NAME,
        password: DB_PWD,
        port: Number(DB_PORT),
    }
)

function getReponse(result: any) {
    return result;
}

const dao = async (query: QueryConfig) => {
    //let res: any = {};
    let result;

    try {
        result = await pool.query(query);
        return result;
    } catch (error) {
        let errObj = Object.assign({}, error)
        throw error

    }


}

export default dao;
// const dao = async (query: QueryObj) => {

//     try {
//         const response = await pool.query(query);
//         //console.log('RESPONSE: ', response);
//         pool.on('error', (error, client) => {
//             throw error;
//         })
//         if (response.rowCount >= 1) {
//             return {command: response.command, rowCount: response.rowCount, oid: response.oid ,rows: response.rows};
//         } else {
//             return {response}
//         }


//     } catch (error) {
//         console.log(error);
//         return 
//         error;
//     }
// };