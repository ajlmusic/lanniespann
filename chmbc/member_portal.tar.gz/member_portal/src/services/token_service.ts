// import dotenv from 'dotenv'
// dotenv.config()
// import jwt, {Secret} from 'jsonwebtoken'

// interface User {
//     username: string,
//     password: string
// }let htmlBody = "<b>Hello world?</b>"
// // dbconn();


// interface Key{ 
    
// }



// class TokenService {

//     }

//     generateAccessToken = jwt.sign(this.payload, secret , { expiresIn: '20s' });
// }



// function generateAccessToken(user:string| object | Buffer, secret: Secret) {

//     this.secret = process.env.ACCESS_TOKEN_SECRET

//     return jwt.sign(user, secret , { expiresIn: '20s' });
    
// }

// function generateRefreshToken(user) {
//     return jwt.sign(user, process.env.REFRESH_TOKEN_SECRET);

// }
