
require('dotenv').config();
import express, { Express, Router } from 'express';
import e, { RequestHandler } from 'express'
import Logger from '../utils/logger'
import morganMiddleware from '../middleware/morganMiddleware'
import jwt from 'jsonwebtoken';
import helmet from 'helmet'
import cors from 'cors';
const app = express();
app.use(helmet());
app.use(morganMiddleware)
app.use(express.json());


const run = function (router: RequestHandler, port: number, serverName: string) {
    const app = express();
    app.use('/', router)

    return app.listen(port, () => {
        console.log(`${serverName} Server listening on port ${port}`)
    })

}

interface Server {
    router: RequestHandler,
    host: any,
    port: number,
    name: string
}

class ExpressServer {

    router: RequestHandler;
    port: number;
    name: string;
    host: string;
    app: Express;

    constructor(router: e.Router, host: string, port: number, name: string) {

        this.router = router;
        this.port = port;
        this.name = name;
        this.host = host;
        this.app = express();
        this.app.use(helmet());
        this.app.use(cors());
        this.app.use(express.json());
        this.app.use('/', this.router);

        this.app.get("/logger", (reg, res) => {
            Logger.error("This is an error log");
            Logger.warn("This is a warn log");
            Logger.info("This is a info log");
            Logger.http("This is a http log");
            Logger.debug("This is a debug log");
        }
        )
    }

    run() {

        this.app.listen(this.port, () => {
            console.log(`${this.name} Server running at http://${this.host}:${this.port} `)
        })
    }

    get server() {
        return this.app;
    }

}

export default ExpressServer;