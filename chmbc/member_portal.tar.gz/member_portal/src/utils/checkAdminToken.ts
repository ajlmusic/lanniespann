import jwt from 'jsonwebtoken'
import { Request, Response, NextFunction } from 'express'



function authenticateToken(req: any, res: Response, next: NextFunction) {
console.log('ADMIN AUTH');

    const authHeader = req.headers['authorization']
    const token = authHeader && authHeader.split(' ')[1]

    if (token == null) return res.sendStatus(401)

    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET as string, (err: any, user: any) => {
        //console.log(err)
        console.log(user);
        
        if (err) return res.sendStatus(403)

       
        if (user.a === 'superadmin' || user.a === 'admin') {

            req.user = user
            next();
        } else  {
            res.sendStatus(403)
        }

    })
}

export default authenticateToken;
