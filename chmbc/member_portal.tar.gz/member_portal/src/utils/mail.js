"use strict";
const nodemailer = require("nodemailer");
const dotenv = require('dotenv');
const { json } = require("express");
dotenv.config();
const {
    SMTP_HOST,
    SMTP_USER,
    SMTP_PASS,
    LIST_OF_RECEIVERS2
} = process.env;


module.exports = async function main(req,res,next) {

  //let data = await res => res.json();

  console.log(res => res.json())
  let testAccount = await nodemailer.createTestAccount();

  let transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: SMTP_USER, // generated ethereal user
      pass: SMTP_PASS, // generated ethereal password
    },
  });

  // send mail with defined transport object
  let info = await transporter.sendMail({
    from: '"CHMBC" <noreply@collegehillchurch.org>', // sender address
    to: LIST_OF_RECEIVERS2, // list of receivers
    subject: "APP", // Subject line
    text: `${req.body.conf_message}`, // plain text body
    html:  res.locals.result, // html body
  });
  console.log("Message sent: %s", info.messageId);
  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

  // Preview only available when sending through an Ethereal account
  console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
  next();
}