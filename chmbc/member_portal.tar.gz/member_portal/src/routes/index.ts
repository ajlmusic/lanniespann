import { Router } from 'express';

import candidateRouter from './candidate_routes';
import electionRouter from './election_routes';
import rosterRouter from './roster_routes'
import authRouter from './auth_routes'
import ballotRouter from './ballot_routes'
import adminRouter from './admin_routes'
import authenticateToken from '../utils/checkToken'
import authenticateAdminToken from '../utils/checkAdminToken'

let rootRouter = Router();

rootRouter.use('/candidate', authenticateToken, candidateRouter);
rootRouter.use('/election', authenticateToken, electionRouter);
rootRouter.use('/auth', authRouter);
// rootRouter.use('/roster', authenticateAdminToken, rosterRouter);
rootRouter.use('/ballot', authenticateToken, ballotRouter);
rootRouter.use('/admin', adminRouter);

//console.log(rootRouter);

export default rootRouter;