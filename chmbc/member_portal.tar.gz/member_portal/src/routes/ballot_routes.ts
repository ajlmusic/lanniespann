import BallotController from '../controllers/ballot_controller'
import { Router} from 'express'
import BallotModel from '../services/models/ballotModel';

const router: Router = Router();
//USERS
router.post('/create', BallotController.create);

export default router;