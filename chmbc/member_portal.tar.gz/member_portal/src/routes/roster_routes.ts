import RosterController from '../controllers/roster_controller'
import { Router} from 'express'

const router: Router = Router();

//router.get('/', RosterController.fetchAll(req: Request , res: Response))

router.get('/', RosterController.fetchAll);
router.get('/:id', RosterController.fetchOneById);
router.put('/update', RosterController.updateOneById);
router.post('/create', RosterController.create)
router.delete('/:id', RosterController.delete)

export default router;