import { Router } from 'express'
import AuthController from '../controllers/auth_controller'
import ElectionController from '../controllers/election_controller'
import CandidateController from '../controllers/candidate_controller'
import BallotController from '../controllers/ballot_controller'
import RosterController from '../controllers/roster_controller'
import authenticateAdminToken from '../utils/checkAdminToken'



const router: Router = Router();

//router.get('/', AuthController.fetchAll);
//router.get('/:id', AuthController.fetchOneById);
//router.put('/update', AuthController.updateOneById);
//router.post('/create', AuthController.create)
//router.delete('/:id', AuthController.delete)
router.post('/login', AuthController.adminLogin)
router.post('/logout', AuthController.logout)

//ELECTIONS
router.get('/election/',authenticateAdminToken, ElectionController.fetchAll);
router.get('/election/:id',authenticateAdminToken, ElectionController.fetchOneById);
router.put('/election/update',authenticateAdminToken, ElectionController.updateOneById);
router.post('/election/create',authenticateAdminToken, ElectionController.create)
router.delete('/election/:id',authenticateAdminToken, ElectionController.delete)

// CANDIDATES
router.get('/candidate',authenticateAdminToken, CandidateController.fetchAll);
router.get('/candidate/:id',authenticateAdminToken, CandidateController.fetchOneById);
router.put('/candidate/update',authenticateAdminToken, CandidateController.updateOneById);
router.post('/candidate/create',authenticateAdminToken, CandidateController.create)
router.delete('/candidate/:id',authenticateAdminToken, CandidateController.delete)

// ELECTRONIC BALLOTS
router.get('/ballot/',authenticateAdminToken, BallotController.fetchAll);
router.get('/ballot/:id',authenticateAdminToken, BallotController.fetchOneById);
router.put('/ballot/update',authenticateAdminToken, BallotController.updateOneById);
router.post('/ballot/create',authenticateAdminToken, BallotController.create);
router.delete('/ballot/:id',authenticateAdminToken, BallotController.delete);


// PAPER BALLOT ROUTES
router.post('/ballot/paper/verify',authenticateAdminToken, BallotController.checkAudit);
router.post('/ballot/paper/add',authenticateAdminToken, BallotController.addPaperBallot);



// ROSTER ROUTES
router.get('/roster',authenticateAdminToken, RosterController.fetchAll);
router.get('/roster/:id',authenticateAdminToken, RosterController.fetchOneById);
router.put('/roster/update',authenticateAdminToken, RosterController.updateOneById);
router.post('/roster/create',authenticateAdminToken, RosterController.create)
router.delete('/roster/:id',authenticateAdminToken, RosterController.delete)

export default router;