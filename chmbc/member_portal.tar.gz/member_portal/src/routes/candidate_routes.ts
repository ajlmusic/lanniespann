import CandidateController from '../controllers/candidate_controller'
import { Router} from 'express'

const router: Router = Router();


router.get('/', CandidateController.fetchAll);


export default router;