import AuthController from '../controllers/auth_controller'
import { Router} from 'express'

const router: Router = Router();

//router.get('/', AuthController.fetchAll);
//router.get('/:id', AuthController.fetchOneById);
//router.put('/update', AuthController.updateOneById);
//router.post('/create', AuthController.create)
//router.delete('/:id', AuthController.delete)
router.post('/login', AuthController.login)
router.post('/logout', AuthController.logout)
router.post('/register', AuthController.register)
export default router;