import ElectionController from '../controllers/election_controller'
import { Router} from 'express'

const router: Router = Router();

//router.get('/', ElectionController.fetchAll(req: Request , res: Response))

router.get('/', ElectionController.fetchAll);

export default router;