const httpLogger = require('./morganMiddleware');

export default httpLogger;