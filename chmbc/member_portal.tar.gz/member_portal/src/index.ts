require('dotenv').config();
import ExpressServer from './loaders';

import { Router } from 'express'
import appRouter from './routes';

const authRouter = Router();
authRouter.get('/', (req, res) => {
    res.json({ msg: "Auth" })
})

const appServer = new ExpressServer(appRouter, 'localhost' , Number(process.env.APP_SERVER_PORT), 'App').run();
const authServer = new ExpressServer(authRouter, 'localhost', 10000,  'Auth').run();