CREATE EXTENSION pgcrypto;

CREATE TABLE public.admins (
    id serial,
    admin_uuid uuid DEFAULT public.uuid_generate_v4(),
    username text,
    password text,
    acl acl_type,
    PRIMARY KEY(id)
);


ALTER TABLE admins ADD UNIQUE (username);
ALTER TABLE public.admins OWNER TO chmbc;

CREATE TYPE public.acl_type AS ENUM (
    'superadmin',
    'admin',
    'user'
);
INSERT INTO admins (username, password, acl) VALUES (
  'nehetek', 
  crypt('kpl0x7D8', gen_salt('bf')), 'superadmin'
);

INSERT INTO admins (username, password, acl) VALUES (
  'admin2', 
  crypt('0762chc', gen_salt('bf')), 'admin'
);

INSERT INTO admins (username, password, acl) VALUES (
  'admin3', 
  crypt('0762chc', gen_salt('bf')), 'admin'
);

INSERT INTO admins (username, password, acl) VALUES (
  'admin4', 
  crypt('0762chc', gen_salt('bf')), 'admin'
);

INSERT INTO admins (username, password, acl) VALUES (
  'user5', 
  crypt('0762chc', gen_salt('bf')), 'user'
);