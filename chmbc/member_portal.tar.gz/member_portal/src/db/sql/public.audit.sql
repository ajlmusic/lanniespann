CREATE TABLE public.audit (
id serial,
audit_date date  DEFAULT CURRENT_DATE NOT NULL,
election_id TEXT NOT NULL,
userid int NOT NULL,
ballot_method ballot_type NOT NULL,
PRIMARY KEY (id)
);

ALTER TABLE public.audit ADD UNIQUE (userid);