CREATE TABLE elections (
    election_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    election_date timestamp with time zone NOT NULL,
    is_election_active boolean DEFAULT false,
    election_title VARCHAR(100),
    election_notes TEXT,
    PRIMARY KEY (election_date)
);