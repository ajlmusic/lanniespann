-- IMPORT DATA --
COPY roster(UserID,FamilyID,FirstName,PreferredName,LastName,FormalFullName,Birthday,Age,Gender,Email,SecondaryEmail,HomePhone,CellPhone,Address,City,State,ZipCode)
FROM '/tmp/chmbc_.csv'
DELIMITER ',' CSV HEADER;
