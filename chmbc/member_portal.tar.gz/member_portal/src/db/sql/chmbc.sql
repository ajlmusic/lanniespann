--
-- PostgreSQL database dump
--

-- Dumped from database version 12.6 (Ubuntu 12.6-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.6 (Ubuntu 12.6-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: add_user_details(); Type: FUNCTION; Schema: public; Owner: chmbc
--

CREATE FUNCTION public.add_user_details() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
         UPDATE users SET user_firstname = roster.firstname, user_lastname = user_roster.lastname, user_email = roster.email, user_cellphone = roster.cellphone WHERE username = roster.userid;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.add_user_details() OWNER TO chmbc;

--
-- Name: roster_create_code(); Type: FUNCTION; Schema: public; Owner: chmbc
--

CREATE FUNCTION public.roster_create_code() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
         UPDATE roster SET RosterKey = CONCAT(LEFT(FirstName,1),chmbc,UserID);
 
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.roster_create_code() OWNER TO chmbc;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_tokens; Type: TABLE; Schema: public; Owner: chmbc
--

CREATE TABLE public.access_tokens (
    id integer NOT NULL,
    access_token text,
    user_id text
);


ALTER TABLE public.access_tokens OWNER TO chmbc;

--
-- Name: access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: chmbc
--

CREATE SEQUENCE public.access_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.access_tokens_id_seq OWNER TO chmbc;

--
-- Name: access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chmbc
--

ALTER SEQUENCE public.access_tokens_id_seq OWNED BY public.access_tokens.id;


--
-- Name: ballot; Type: TABLE; Schema: public; Owner: chmbc
--

CREATE TABLE public.ballot (
    ballot_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ballot_date timestamp with time zone DEFAULT now() NOT NULL,
    election_id character varying(100) NOT NULL,
    candidate_id character varying(100) NOT NULL,
    usr_id character varying(100) NOT NULL,
    ballot_response character varying(100) NOT NULL
);


ALTER TABLE public.ballot OWNER TO chmbc;

--
-- Name: candidate; Type: TABLE; Schema: public; Owner: chmbc
--

CREATE TABLE public.candidate (
    candidate_id integer NOT NULL,
    ballot_date timestamp with time zone NOT NULL,
    title character varying(100),
    firstname character varying(100),
    middlename character varying(100),
    lastname character varying(100),
    "position" character varying(100),
    bio text,
    image_location character varying(100)
);


ALTER TABLE public.candidate OWNER TO chmbc;

--
-- Name: candidate_candidate_id_seq; Type: SEQUENCE; Schema: public; Owner: chmbc
--

CREATE SEQUENCE public.candidate_candidate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.candidate_candidate_id_seq OWNER TO chmbc;

--
-- Name: candidate_candidate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chmbc
--

ALTER SEQUENCE public.candidate_candidate_id_seq OWNED BY public.candidate.candidate_id;


--
-- Name: roster; Type: TABLE; Schema: public; Owner: chmbc
--

CREATE TABLE public.roster (
    roster_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    userid integer,
    familyid integer,
    rosterkey character varying(100),
    firstname character varying(100),
    preferredname character varying(100),
    lastname character varying(100),
    formalfullname character varying(100),
    birthday character varying(100),
    age character varying(100),
    gender character varying(100),
    email character varying(100),
    secondaryemail character varying(100),
    homephone character varying(100),
    cellphone character varying(100),
    address character varying(100),
    city character varying(100),
    state character varying(100),
    zipcode character varying(100),
    chmbc integer DEFAULT 1600
);


ALTER TABLE public.roster OWNER TO chmbc;

--
-- Name: users; Type: TABLE; Schema: public; Owner: chmbc
--

CREATE TABLE public.users (
    id integer NOT NULL,
    user_uuid uuid DEFAULT public.uuid_generate_v4(),
    username text,
    user_password text
);


ALTER TABLE public.users OWNER TO chmbc;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: chmbc
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO chmbc;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chmbc
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: access_tokens id; Type: DEFAULT; Schema: public; Owner: chmbc
--

ALTER TABLE ONLY public.access_tokens ALTER COLUMN id SET DEFAULT nextval('public.access_tokens_id_seq'::regclass);


--
-- Name: candidate candidate_id; Type: DEFAULT; Schema: public; Owner: chmbc
--

ALTER TABLE ONLY public.candidate ALTER COLUMN candidate_id SET DEFAULT nextval('public.candidate_candidate_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: chmbc
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: access_tokens; Type: TABLE DATA; Schema: public; Owner: chmbc
--

COPY public.access_tokens (id, access_token, user_id) FROM stdin;
5	63c3ce9e5181ba800ea573fbbabbce710d470d0f	3
6	07ec3fe3d3ff788680fcb47c88273e431310c77f	3
7	18edf97d2ffc03b958713b4287c217a4dd738798	4
\.


--
-- Data for Name: ballot; Type: TABLE DATA; Schema: public; Owner: chmbc
--

COPY public.ballot (ballot_id, ballot_date, candidate_id, usr_id, ballot_response) FROM stdin;
\.


--
-- Data for Name: candidate; Type: TABLE DATA; Schema: public; Owner: chmbc
--

COPY public.candidate (candidate_id, ballot_date, title, firstname, middlename, lastname, "position", bio, image_location) FROM stdin;
2	2021-05-01 09:00:00-05	Reverend	Chauncy	L.	Jordan, Sr.	Pastor	\N	\N
6	2021-05-02 00:00:00-05	Dr	John	D	Doe	Pastor	 	 
8	2021-05-02 00:00:00-05	Dr	Bobby	D	Carson	Pastor	 	 
9	2021-05-02 00:00:00-05	Dr	Bobby	D	Carson	Pastor	 	 
10	2021-05-02 00:00:00-05	Dr	Bobby	D	Carson	Pastor	 	 
11	2021-05-02 00:00:00-05	Dr	Bobby	D	Carson	Pastor	 	 
12	2021-05-02 00:00:00-05	Dr	Bobby	D	Carson	Pastor	 	 
7	2021-05-02 00:00:00-05	Rev.	Bobby	Deon	Carson	Pastor	 	 
\.


--
-- Data for Name: roster; Type: TABLE DATA; Schema: public; Owner: chmbc
--

COPY public.roster (roster_id, userid, familyid, rosterkey, firstname, preferredname, lastname, formalfullname, birthday, age, gender, email, secondaryemail, homephone, cellphone, address, city, state, zipcode, chmbc) FROM stdin;
0cab807b-53b1-4b80-8964-30cce4aa69ba	871	379	J1600871	John	\N	Hoye	\N	\N	\N	\N	\N	\N	\N	\N	3666 Hollywood	Jackson	MS	39213	1600
70d044a3-4414-4878-ad4d-2a21a3cf1716	2148	2146	K16002148	Khaliah	\N	Brown	\N	\N	\N	\N	\N	\N	\N	\N	1633 Shirley Avenue	Jackson	MS	39204	1600
3e84a404-8ec4-4795-93d8-7eace2146637	3642	619	S16003642	Stephanie	\N	Parker Smith	\N	\N	\N	Female	\N	\N	601-924-1144	\N	407 Parker Drive	Clinton	MS	39056	1600
43ae508f-a32c-4b3d-92d8-d30449cfcb43	3432	3189	R16003432	Ryan	\N	Smith	\N	\N	\N	\N	\N	\N	601.969.6516	\N	413 Fredrica Avenue	Jackson	MS	39209	1600
e7e2588d-cd26-4194-8bcd-38a95e1749f6	3474	811	A16003474	Anaya	\N	Henry	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1600
767335d5-337b-4ca6-9aa5-ffee4773f540	3229	3595	K16003229	Kiya	\N	Martin	\N	\N	\N	Female	\N	\N	\N	\N	167 Whisper Lake Blvd.	Madison	MS	39110	1600
3d2880a6-deb2-445d-bbf0-e1012c5a3236	3365	3362	B16003365	Barbara	\N	Reed	\N	9/27/1949	71 yrs	\N	\N	\N	601-362-9638	\N	150 Needle Cove Drive	Jackson	MS	39206	1600
a24917b5-ddff-4a32-acb4-07cfdbab668f	2071	2069	C16002071	Camille	\N	Haynes	\N	1/2/1900	121 yrs	\N	\N	\N	601-201-0449	\N	919 Barberry Avenue	Jackson	MS	39204	1600
ff9d4bea-5481-471f-986c-d9ce1af86aac	2099	2002	C16002099	Corbin	\N	Wilson	\N	\N	\N	\N	\N	\N	601-829-0535	\N	303 La Coste Ct.	Brandon	MS	39047	1600
965747b0-0caf-4d07-8593-4d2de8a7a94b	3652	1290	J16003652	Jasmine	\N	Greathree	\N	\N	\N	Female	\N	\N	601-896-3511	\N	260 Pearlie Owens Dr.	Jackson	MS	39212	1600
6cf61c11-577f-42c1-b884-c3e122c04d9f	3522	3520	W16003522	William	\N	Arnold	\N	5/7/1952	68 yrs	Male	\N	\N	\N	\N	501 Northpointe Pkwy, #214	Jackson	MS	39211	1600
855df12f-cc18-4dca-9d8e-cc1acf20bb29	994	995	A1600994	Antwan	\N	Prowell	\N	11/30/1986	34 yrs	Male	\N	\N	601-487-6682	\N	100 Cedarwood Drive	Jackson	MS	39212	1600
4d56521c-5420-47fa-a7c2-def27b173fd0	1794	1525	J16001794	Jaylon	\N	Clemons	\N	4/20/1999	21 yrs	\N	\N	\N	601-850-7337	\N	4643 Casablanca Dr.	Jackson	MS	39206	1600
3f189db7-5127-4cab-bc63-646b20b6cbcd	398	395	S1600398	Shemiah	\N	Jacobs	\N	1/11/1985	36 yrs	Male	\N	\N	601-954-3286	\N	202 Dona Ave.	Jackson	MS	39212	1600
e85a7db2-54e8-4628-a656-b4cbdf783045	2021	882	A16002021	Ashley	\N	Knight	\N	\N	\N	\N	\N	\N	601-201-3027	\N	126 Brisco Street	Madison	MS	39110	1600
4adbf97c-c1eb-41c1-b85f-d6049b8fadda	3653	1290	Q16003653	Quentin	\N	Greathree	\N	\N	\N	Male	\N	\N	601-896-3511	\N	260 Pearlie Owens Dr.	Jackson	MS	39212	1600
1376e1f1-dc0f-4761-8e44-2f31d413a6a6	406	404	M1600406	Marcus	\N	Johnson	\N	7/2/1984	36 yrs	Male	\N	\N	601-398-3872	\N	3205 Copperfield	Jackson	MS	39209	1600
ec77a5d5-6d8a-4d07-9d0b-c9580e19d01a	1732	1074	P16001732	Paul-James	\N	Curry	\N	8/23/2001	19 yrs	\N	\N	\N	601-372-5745	\N	182 Lea Circle	Jackson	MS	39204	1600
2be9bab2-edab-4849-84c5-f776c4653b47	1722	212	J16001722	James	\N	Alyssa	\N	\N	\N	\N	\N	\N	601-981-7747	\N	837 Buttonwood	Jackson	MS	39206	1600
18ba26d0-a5c5-4b5a-888e-4816d512fac8	816	1088	Y1600816	Yancey	\N	Oatis	\N	6/19/1985	35 yrs	Male	\N	\N	601-948-0043	\N	1015 Laura Ave.	Jackson	MS	39209	1600
84c6776d-6f02-4b6a-bd4f-8518c3603201	498	496	L1600498	Lisa	\N	Moses	\N	10/3/1963	57 yrs	Female	\N	\N	601-497-1707	\N	1849 Cape Cove	Richland	MS	39218	1600
5fb0c3c3-92c2-4af6-a975-7dda61d75909	3309	1330	J16003309	Jailyn	\N	Myers	\N	\N	\N	\N	\N	\N	601-622-3806	\N	4952 Brookwood Place	Jackson	MS	39272	1600
33e75bc0-deea-40c4-83ae-b2942b9fbc0a	3328	379	S16003328	Sandra	\N	Hoye	\N	12/24/1966	54 yrs	\N	\N	\N	\N	\N	3666 Hollywood	Jackson	MS	39213	1600
ebea6337-56cb-4871-ad44-dd39188b6480	3525	2068	J16003525	Jamari	\N	Tate	\N	\N	\N	\N	\N	\N	601-373-7113	\N	409 Horseshoe Cove	Byram	MS	39272	1600
553c5a12-42f3-428b-8b38-4f0620d7dd6f	1643	1546	T16001643	Tanna	\N	Bryant	\N	8/23/2003	17 yrs	Female	\N	\N	601-969-0871	\N	237 Myer Ave.	Jackson	MS	39209	1600
3d41652d-24e0-4651-b6c4-b3b8d83e63ea	3654	1290	D16003654	Darius	\N	Greathree	\N	\N	\N	Male	\N	\N	601-896-3511	\N	260 Pearlie Owens Dr.	Jackson	MS	39212	1600
bc2d6839-0b86-4220-b3f7-438f8eeed055	3376	315	J16003376	Joseph	\N	Davis	\N	\N	\N	\N	\N	\N	601-373-7006	\N	309 South Haven Dr.	Jackson	MS	39272	1600
c74bac70-03cc-4f39-86d4-e2344b6a5881	3245	3243	E16003245	Eric	\N	Armstrong	\N	1/15/1971	50 yrs	Male	\N	\N	601.259.2513	\N	123 Abigail Cove	Byram	MS	39272	1600
f911a0d5-9a3d-449f-90c4-e5e1eb266e6e	133	131	K1600133	Koffi	\N	Barnes	\N	10/12/1976	44 yrs	\N	\N	\N	601-813-3003	\N	4758 Brookwood Place	Jackson	MS	39272	1600
13b1b8cf-fa7d-478d-af49-e018bf71982f	659	653	J1600659	James	\N	Terry	\N	\N	\N	Male	\N	\N	601-454-7613	\N	131 South Denver St.	Jackson	MS	39209	1600
3789f158-918f-4885-9d91-467a182ed325	646	642	W1600646	Willie	\N	Tate	\N	\N	\N	Male	\N	\N	601-355-5232	\N	2616 Hemingway Circle	Jackson	MS	39209	1600
d3813e3c-afd8-45ae-a9af-7cd2c4c58527	280	278	J1600280	Jacob	\N	Byas	\N	1/20/1947	74 yrs	Male	\N	\N	601-353-2328	\N	538 Fredrica Ave	Jackson	MS	39209	1600
1df9f767-5b13-4e29-bf8c-ae4e24a86f79	1848	1846	J16001848	John	\N	Overton	\N	\N	\N	\N	\N	\N	\N	\N	728 Mary Lee St.	Jackson	MS	39203	1600
a44f5b37-989b-4929-85e2-69ca84f154cd	903	191	V1600903	Vanessa	\N	Gleese	\N	1/2/1900	121 yrs	\N	\N	\N	601-969-3352	\N	268 Lexington Ave	Jackson	MS	39209	1600
2f2ebe0d-fd69-44b8-beb0-bcf12a272fe6	3339	3189	J16003339	Jabari	\N	Harris	\N	\N	\N	\N	\N	\N	\N	\N	413 Fredrica Avenue	Jackson	MS	39209	1600
e78cbdae-5887-420e-9549-58e802f11bb5	2152	3253	R16002152	Robert	\N	Clark IV	\N	\N	\N	Male	\N	\N	601-668-0820	\N	111 Bear Creek Ct	Canton	MS	39046	1600
ed57ba15-50fc-4abe-9386-abc6e4a3c7b9	3645	3424	M16003645	Monique	\N	Jackson	\N	1/9/2004	17 yrs	Female	\N	\N	\N	\N	1451 Norhlake Dr.	Jackson	MS	39211	1600
2ebb2ade-f612-4b1e-ae7c-f2e5b7ba82f0	3638	935	J16003638	John	\N	Coleman Hall	\N	\N	\N	\N	\N	\N	\N	\N	4279 Glenn Oak Circle	Byram	MS-Mississippi	39272	1600
792ac187-6f5f-4dcc-9047-08ecc6facf0c	121	117	M1600121	Michelle	\N	Wright	\N	9/16/1984	36 yrs	Female	\N	\N	\N	\N	153 Winchester St.	Byram	MS	39272	1600
e5b8ed80-f73e-4230-b49b-9ae047f17711	1682	1074	M16001682	Monica	\N	Curry	\N	1/27/1998	23 yrs	Female	\N	\N	601-594-7570	\N	182 Lea Circle	Jackson	MS	39204	1600
916465b1-981d-4736-abcc-d765db6a3e7d	3651	1290	Z16003651	Zelda	\N	Greathree	\N	\N	\N	Female	\N	\N	601-896-3511	\N	260 Pearlie Owens Dr.	Jackson	MS	39212	1600
9cc951e4-40a7-4e1e-84d3-71a2b21a0641	3639	3595	K16003639	Kwesi	\N	Martin	\N	\N	\N	Male	\N	\N	\N	\N	167 Whisper Lake Blvd.	Madison	MS	39110	1600
b9b535ee-5401-4264-b933-bb47ae431e44	1583	1581	V16001583	Vanessa	\N	Myles	\N	4/28/1961	59 yrs	Female	\N	\N	\N	\N	5103 Brookview Dr.	Jackson	MS	39212	1600
67a0a5c3-17dd-47a5-b51c-99c7e1a4d494	592	590	A1600592	Adrian	\N	Adams	\N	1/25/1987	34 yrs	\N	\N	\N	601-362-0081	\N	6183 Woodhaven Road	Jackson	MS	39206	1600
540c9315-2e3c-418e-ad2b-9f5553f9193a	1827	1551	J16001827	Jackson	\N	Morris	\N	4/20/2009	11 yrs	\N	\N	\N	601-898-7740	\N	227 Lake Circle	Madison	MS	39110	1600
d9ea4d40-c9cc-45a0-a737-17394da5ad69	1921	1919	L16001921	Linda Faye	Linda	Williams	\N	\N	\N	\N	\N	\N	\N	\N	1403 Florence Ave.	Jackson	MS	39204	1600
f8ab6e85-816b-4808-9604-c690a0c26ea5	2073	2071	L16002073	Linda	\N	Parker	\N	1/2/1900	121 yrs	\N	\N	\N	\N	\N	1521 Hill Avenue	Jackson	MS	39204	1600
b429cd7c-9025-49d6-a882-71e0eb488a56	143	140	T1600143	Toni	\N	Moore	\N	11/16/1960	60 yrs	Female	\N	\N	601-362-2473	\N	8 Justin Court	Jackson	MS	39206	1600
6dfd1144-dfff-4e3f-9412-212323cb1486	3650	\N	R16003650	Ry'n	\N	Good	\N	10/1/1999	21 yrs	Female	\N	\N	601-372-1570	\N	123 Abigail Cove	Byram	MS	39272	1600
240fbecf-abcc-4870-a24e-5b1d03bda129	1788	212	A16001788	Alyssa	\N	James	\N	\N	\N	Female	\N	\N	601-981-7747	\N	837 Buttonwood	Jackson	MS	39206	1600
25af66df-749e-49d7-8e1e-0a2326df9930	3458	2070	N16003458	Nirvana	\N	Taylor	\N	\N	\N	\N	\N	\N	601-850-6829	\N	1230 Hill Avenue	Jackson	MS	39204	1600
0e2ded8a-c084-41cb-907f-bd87d515a407	3640	3595	C16003640	Catina	\N	Martin	\N	\N	\N	Female	\N	\N	\N	\N	167 Whisper Lake Blvd.	Madison	MS	39110	1600
7bb02732-9432-4c50-a780-308b991d0e2c	517	513	J1600517	Justin	\N	Randolph	\N	10/20/1987	33 yrs	Male	\N	\N	601-372-8160	\N	1342 Hair St.	Jackson	MS	39204	1600
f7a0a5c9-ddec-49c2-838c-35178a5ce4f9	1870	1833	K16001870	Khaliah	\N	Harris	\N	\N	\N	\N	\N	\N	601-760-0665	\N	1633 Shirley Avenue	Jackson	MS	39204	1600
b8049e88-bf01-4869-a8d7-2cce21e3dc81	3551	405	T16003551	Taylor	\N	Johnson	\N	\N	\N	\N	\N	\N	(601) 750--5756	\N	313 Brookside Cove	Terry	MS	39170	1600
b69d5934-9fee-4ccb-94b9-4870d0c4316e	3624	\N	A16003624	Anejia	\N	Mann	\N	10/5/2000	20 yrs	Female	anejiamann1005@gmail	\N	616-655-4705	\N	\N	\N	\N	\N	1600
365bb694-643d-47dc-b30d-bb82f171b8d3	1662	1660	W16001662	Walter	\N	Booker	\N	10/17/1943	77 yrs	Male	\N	\N	601-926-1866	\N	210 Lindale Cir.	Clinton	MS	39056	1600
0dec8799-1bcd-4a15-a29f-3cc9d0df4020	1432	1430	A16001432	Atarah	\N	Price	\N	2/18/1987	34 yrs	Female	\N	\N	\N	\N	1719 Hair St.	Jackson	MS	39204	1600
82c37b54-de30-4619-9ca4-9d48326f9fe3	2030	316	T16002030	Tracy	\N	Davis	\N	9/4/1900	120 yrs	\N	\N	\N	601-540-0941	\N	4059 Henderson Rd.	Byram	MS	39272	1600
d6cd499e-dc7f-4572-86cd-4d176d451a16	3553	3249	J16003553	Justin	\N	Collins	\N	\N	\N	\N	\N	\N	601-720-9767	\N	615 Walnut Grove Drive	Pearl	MS	39208	1600
038ea027-e66f-4aaa-9883-fb456f4d650f	3540	1311	Z16003540	Zoe	\N	Nash	\N	\N	\N	Female	\N	\N	601-213-7482	\N	404 Violet Dr.	Madison	MS	39110	1600
a8dc3995-e3c1-4dba-a8ae-ca2190c1ff0a	1538	1299	E16001538	Ervin	\N	Honer	\N	\N	\N	\N	\N	\N	601-352-7044	601-506-9797	1210 Wiggins St.	Jackson	MS	39203	1600
49df2ae6-20bd-4aa9-935f-ecee5a93885e	1591	1589	T16001591	Terrance	\N	Mitchell	\N	5/22/1970	50 yrs	Male	\N	\N	\N	\N	2611 Glenn St.	Jackson	MS	39204	1600
8e5b5fc1-889d-4571-9b3c-694fa8b259b3	1316	1326	S16001316	Stephanie	\N	Gant	\N	9/10/1981	39 yrs	Female	\N	\N	\N	\N	1502 Schoolview Dr.	Jackson	MS	39213	1600
69a5f3d7-3ccc-4268-a87b-e7d9909436b6	119	117	D1600119	Deborah Wright	Deborah	Armstrong	\N	7/22/1951	69 yrs	Female	\N	\N	\N	\N	153 Winchester St.	Byram	MS	39272	1600
36ffffed-619c-4375-b6e9-3e95bd2ba23a	1091	1088	B16001091	Bryant	\N	Oatis	\N	10/24/1980	40 yrs	Male	\N	\N	601-948-0043	\N	1015 Laura Ave.	Jackson	MS	39209	1600
7929a117-be92-4d5e-8c23-fe9aaf3cdb4b	1582	1580	L16001582	Linda	\N	Kinnard	\N	8/11/1955	65 yrs	Female	\N	\N	601-842-5269	\N	127 Sollitt St.	Jackson	MS	39209	1600
de3c2e89-a3c6-43b7-ae31-8c0daa005bf4	247	242	M1600247	Mia	\N	Morris	\N	4/5/1970	51 yrs	Female	\N	\N	601-981-8330	\N	5914 Canterbury Rd	Jackson	MS	39206	1600
21e96c3c-5bfe-47cf-81d3-c6ae619403ce	3623	\N	T16003623	TaShyla	\N	Pratt	\N	6/18/1998	22 yrs	Female	tashylapratt18@gmail.com	\N	612-701-2691	\N	\N	\N	\N	\N	1600
d6bbe5a2-8460-43fa-af69-71cb619975e4	377	372	G1600377	George	\N	Hood Jr.	\N	7/14/1989	31 yrs	Male	\N	\N	601-213-2420	\N	1448 Forbes Drive	Jackson	MS	39272	1600
fb633b42-5b27-44ca-b1f3-c5dcc2287c63	450	448	H1600450	Herbert	\N	Marshall	\N	1/2/1900	121 yrs	Male	\N	\N	\N	\N	903 Arbor Vista	Jackson	MS	39209	1600
855369b4-2230-476a-a37d-feffe74efc1c	3621	2177	J16003621	Jordan	\N	Adams	\N	7/6/2009	11 yrs	Male	\N	\N	601-927-5884	\N	5809 Orchardview Drive	Jackson	MS	39211	1600
eee283b4-bd28-43c3-b796-fe4f49f7ed8b	15	13	D160015	David	\N	Abron	\N	12/10/1947	73 yrs	Male	\N	\N	662-902-0353	601-955-5141	4454 Liberty Hill Rd.	Jackson	MS	39206	1600
197587e3-03a1-4ccd-b3bc-65eb1ab8d8c2	108	103	V1600108	Vera	\N	Adams	\N	5/1/1900	120 yrs	Female	veraadams04@yahoo.com	\N	601-362-0081	\N	6183 Woodhaven Rd.	Jackson	MS	39206	1600
1ff30d2c-a85f-44e2-a369-3270ebe7a5b9	3479	3477	R16003479	Robert	\N	Shearry	\N	2/10/1959	62 yrs	Male	\N	\N	601.896.6731	\N	2123 Queensroad Avenue	Jackson	MS	39213	1600
2da6141e-7ef0-4cd4-8336-a96cc6383d29	332	330	R1600332	Ruby	\N	Frazier	\N	12/2/1939	81 yrs	Female	\N	\N	601-362-9778	\N	113 California Place	Jackson	MS	39213	1600
ec534546-47e4-4688-8b1e-5f4cbd2d21a3	115	113	D1600115	Derrick	\N	Amos Sr.	\N	11/17/1971	49 yrs	Male	damos1171@yahoo.com	\N	601-373-0379	601-613-1746	9879 Crooked Creek Blvd.	Byram	MS	39272	1600
7fac54da-274c-48ff-ba90-36a94b2b7b36	3345	3343	M16003345	Marcus	\N	Franklin	\N	5/23/1980	40 yrs	Male	\N	\N	601.347.9145	\N	650 Windward Lane	Richland	MS	39218	1600
a539fc77-d77a-4d7b-87dc-613a1546a43f	1490	1488	L16001490	Lucrecia	\N	Spann	\N	8/24/1980	40 yrs	Female	\N	\N	601-376-7291	\N	1710 Florence Ave.	Jackson	MS	39204	1600
cf16a79d-eef0-4cab-986d-965b9e5982ea	1021	1020	P16001021	P'atra	\N	Parker	\N	2/1/1989	32 yrs	Female	\N	\N	601-373-9633	\N	118 Rowan Oak Place	Terry	MS	39170	1600
c4e5d844-7df1-451e-a656-d94f1f5f7ec0	124	122	D1600124	Druthie	\N	Bailey	\N	6/4/1955	65 yrs	Female	druthie55@yahoo.com	\N	601-948-6240	601-961-5402	1329 Florence Avenue	Jackson	MS	39204	1600
ae0e0021-ed55-4347-8bee-d3cc9bafbd48	127	749	E1600127	Elisia Louella	Elisia	Watkins	\N	6/13/1960	60 yrs	\N	\N	\N	601-720-5333	\N	747 Wingfield St.	Jackson	MS	39209	1600
4bef2acb-ce1a-4151-b70f-d73d2470fd38	408	403	L1600408	Leanna	\N	Johnson	\N	8/30/1986	34 yrs	Female	\N	\N	601-398-3872	\N	3205 Copperfield	Jackson	MS	39209	1600
cfb78cff-d3b1-4d92-8ce9-9d9c11b91703	1670	3253	L16001670	Leah F.	Leah	Clark	\N	11/8/2002	18 yrs	Female	\N	\N	601-668-0820	\N	111 Bear Creek Ct	Canton	MS	39046	1600
d290177d-9556-4a34-ad3b-119884217e84	132	130	B1600132	Beverly	\N	Barnes	\N	9/7/1950	70 yrs	Female	bbarnes2003@aol.com	\N	601-362-3042	601-506-0190	4758 Brookwood Place	Jackson	MS	39272	1600
6de264f7-0b14-4994-8deb-a0e546944a31	204	902	T1600204	Tiffany	\N	Henderson	\N	2/22/1982	39 yrs	Female	\N	\N	769-251-1100	\N	410 Justin Cove	Byram	MS	39272	1600
31c5ef7a-aa0c-44b7-9667-471045d74a6f	134	132	J1600134	Joseph	\N	Bartee Sr.	\N	7/31/1942	78 yrs	Male	\N	\N	601-362-2090	\N	6857 F.D. Roosevelt DR.	Jackson	MS	39213	1600
e7e87fac-7d47-4e8a-b7b4-87c373d5d005	368	366	A1600368	Antonio V.	Antonio	Hayes	\N	9/3/1972	48 yrs	Male	\N	\N	601-813-8837	\N	308 Swan Lake	Jackson	MS	39212	1600
f8fcb1f8-65db-44d5-b33e-e48dc6ec8b55	135	132	J1600135	Joseph	\N	Bartee Jr.	\N	5/31/1966	54 yrs	Male	\N	\N	601-362-2090	\N	6857 F.D. Roosevelt DR.	Jackson	MS	39213	1600
ec72eff0-74ed-482c-bff9-309f5a2b530a	142	140	G1600142	Gene	\N	Moore	\N	10/24/1958	62 yrs	Male	\N	\N	601-362-2473	601-954-4363	8 Justin Court	Jackson	MS	39206	1600
a67cc63e-43e5-43e8-bb78-18b19c2ce748	3612	\N	A16003612	Areda	\N	Cockrell-Harris	\N	\N	\N	Female	acharrisjd@gmail.com	\N	\N	\N	1031 Meadowbrook Rd.	Jackson	MS	39206	1600
0eb217ce-f8ed-4287-957d-0079c6b7946b	155	558	M1600155	Mary Joyce	Mary	Sanders	\N	7/30/1900	120 yrs	Female	hatladydst@gmail.com	\N	601-278-3853	\N	421 Lexington Ave	Jackson	MS	39204	1600
60a43525-5d8a-4ed0-a502-db167ab9171c	3627	\N	N16003627	Nia	\N	Hodges	\N	\N	\N	Female	niahodges@gmail.com	\N	205-246-6203	\N	JSU P. O. Box 190075	Jackson	MS	39217	1600
19d31d9e-2b27-4a3b-bf0d-9a5003508a8f	156	154	K1600156	Katrina	\N	Turner	\N	2/7/1961	60 yrs	Female	KT3743@gmail.com	\N	601-201-0543	\N	2033 Wisteria Drive	Jackson	MS	39204	1600
d01f0c96-6a3b-4e4d-a22c-3b40e1499960	1560	3593	J16001560	Jessica	\N	Pamplin	\N	10/7/1995	25 yrs	Female	\N	\N	601-922-7025	\N	3420 Dundee Lane	Jackson	MS	39212	1600
edf210c2-3edf-486c-8c48-e95218ae2430	1725	3243	S16001725	Sarah	\N	Armstrong	\N	8/29/1972	48 yrs	Female	\N	\N	601.259.2513	\N	123 Abigail Cove	Byram	MS	39272	1600
c2511831-47c7-4995-bfbd-e91d00b0c41d	157	155	L1600157	Latondria	\N	Turner-Banks	\N	8/11/1981	39 yrs	Female	tlatondria@yahoo.com	\N	601-519-6689	\N	1223 Cliffdale Street	Clinton	MS	39056	1600
8eae9a56-64ea-488e-a4e3-26113a3e4267	158	156	D1600158	Dyandrea	\N	Kennedy	\N	8/24/1990	30 yrs	Female	dymariu08@yahoo.com	\N	601-260-4546	\N	2033 Wisteria Drive	Jackson	MS	39204	1600
85660b23-e5df-4094-a8a4-a120f9454d37	166	164	L1600166	LoEsther	\N	Benson	\N	12/23/1900	120 yrs	Female	\N	\N	601-352-9867	\N	750 Buena Vista Ave	Jackson	MS	39209	1600
b598c142-d9df-4627-beec-121d200de3e5	3349	3347	B16003349	Brenda	\N	Shay-Wilkinson	\N	8/19/1965	55 yrs	Female	\N	\N	601-502-6235	\N	223 Kimbrough	Jackson	MS	39204	1600
b714bbda-5d0b-4189-909f-ce59f99143ee	168	166	E1600168	Edna	\N	Caston	\N	7/10/1955	65 yrs	Female	erdcast@bellsouth.net	\N	601-924-9858	\N	755 Cherry Stone Drive	Clinton	MS	39056	1600
bad37923-1bf2-4736-b84b-6d18c5ac1112	169	166	D1600169	Donovan	\N	Caston	\N	6/4/1987	33 yrs	Male	\N	\N	601-924-9858	\N	755 Cherry Stone Drive	Clinton	MS	39056	1600
aceab422-303e-4cce-b7a6-1765da23844a	631	628	G1600631	Gwen	\N	Staffney	\N	10/2/1900	120 yrs	Female	\N	\N	601-857-8431	\N	2381 Dupree Rd.	Raymond	MS	39154	1600
f1ef9086-d6ec-490a-a731-ce4ce88de562	255	253	C1600255	Carvin Lamar	Carvin	Bridges	\N	12/21/1939	81 yrs	Male	\N	\N	601-201-5356	\N	730 Eastview St	Jackson	MS	39209	1600
a80798cc-cda6-4d49-838d-5117c47f23c6	905	903	L1600905	Lottie	\N	Johnson	\N	8/6/1944	76 yrs	Female	\N	\N	601-977-9693	\N	755 Glencross Drive	Jackson	MS	39206	1600
51b0f889-083b-4e82-aa08-f0bcf1febe09	791	787	L1600791	Louis P (Ricky)	\N	Wright Jr.	\N	3/2/1977	44 yrs	Male	\N	\N	601-371-6687	\N	1344 Tanglewood Place	Jackson	MS	39204	1600
14089895-9f09-4ef8-9f5a-8f08c11b684c	1003	749	J16001003	Jaalyn	\N	Williams	\N	3/22/1994	27 yrs	Female	\N	\N	601-720-5333	\N	747 Wingfield St.	Jackson	MS	39209	1600
7e6ac20c-98ea-4eb1-ae2b-459f7072c558	996	995	N1600996	Nicholas	\N	Prowell	\N	4/26/1990	30 yrs	Male	\N	\N	601-487-6682	\N	100 Cedarwood Drive	Jackson	MS	39212	1600
5ebe0cbf-bab0-41a3-8655-f27e495a347e	170	168	L1600170	Lee Marcus	Lee	Collins	\N	8/15/1939	81 yrs	Male	lcollins815@hotmail.com	\N	601-982-9505	601-259-9084	3560 Holmes Ave.	Jackson	MS	39213	1600
7256575c-527b-4d65-976e-809f10a41980	176	174	R1600176	Robert E	Robert	Dow Sr.	\N	9/19/1931	89 yrs	Male	\N	\N	601-922-8890	\N	5152 Gault St	Jackson	MS	39209	1600
800a5390-4b29-46b7-a830-95fe0a936c9e	177	174	M1600177	Malena W.	\N	Dow	\N	11/4/1935	85 yrs	Female	mwdow1104@gmail.com	\N	601-922-8890	601-988-8054	5152 Gault St	Jackson	MS	39209	1600
ed836ddc-ac76-4b03-ac31-c5baf26e81b4	1400	218	M16001400	Matthew	\N	Jenkins	\N	10/7/1996	24 yrs	Male	\N	\N	601-201-2895	\N	140 Glenwild Trl.	Canton	MS	39046	1600
499741ac-7010-45e1-96d9-337f421e4474	179	177	M1600179	Mary	\N	Fisher	\N	1/10/1961	60 yrs	Female	mfthompsa@gmail.com	\N	601-259-0128	601-259-0128	7752 Hwy 18 West	Jackson	MS	39209	1600
1d694767-a75e-458e-9e75-ae6fbb19f006	3595	\N	E16003595	Emily	\N	Amos	\N	\N	\N	Female	emilyamos31@gmail.com	\N	601-941-7067	\N	122 Quail Run Drive	Madison	MS	39110	1600
bc01ce99-82fb-45d8-8ad2-360969fc17e8	180	178	R1600180	Robert C.	Robert	Fisher	\N	12/18/1965	55 yrs	Male	bratschebob@yahoo.com	\N	773-817-5017	\N	7752 Highway 18	Jackson	MS	39209	1600
ee45294b-44ae-4fb4-b798-c497ad996aa6	282	278	D1600282	Damien Kenyn	Damien	Byas	\N	5/23/1976	44 yrs	Female	\N	\N	601-353-2328	\N	538 Fredrica Ave	Jackson	MS	39209	1600
c7cdf928-feb6-4ab9-a0d0-f4366e218118	183	181	P1600183	Perella Monique	Perella	Fisher-Smith	\N	8/27/1990	30 yrs	Female	Perella7@gmail.com	\N	601-667-7552	\N	337 W. Oak Leaf Ct.	Ridgeland	MS	39157	1600
bc751fbb-10e3-4d6b-86fc-72524e4e466d	1637	749	B16001637	Brenden	\N	Watkins	\N	12/1/1988	32 yrs	Male	\N	\N	601-720-5333	\N	747 Wingfield St.	Jackson	MS	39209	1600
7447d73a-15c9-468b-8c0e-2e51a7279402	188	186	J1600188	Juanita Sanders	Juanita	Fisher	\N	2/4/1941	80 yrs	Female	perfish41@gmail.com	\N	601-922-9085	\N	7752 Highway 18 West	Jackson	MS	39209	1600
934421cc-705a-40f8-a9b0-e36c87ecc251	193	191	S1600193	Sam H.	Sam	Gleese Jr.	\N	3/21/1947	74 yrs	Male	denise.gleese@yahoo.com	\N	601-969-3352	601-927-4649	268 Lexington Ave	Jackson	MS	39209	1600
e9867474-6fbb-48f5-ba80-952434e8eb71	194	191	N1600194	Nicole	\N	Gleese	\N	9/7/1900	120 yrs	Female	\N	\N	601-969-3352	\N	268 Lexington Ave	Jackson	MS	39209	1600
b21b04ab-7f37-4d9c-9408-5062ed460e4b	197	195	D1600197	Denise	\N	Griffin	\N	3/6/1957	64 yrs	Female	deltadee36@hotmail.com	\N	601-259-2429	601-259-2429	700 Huntington Cove	Madison	MS	39110	1600
49340217-4d97-45d9-a4a5-439649c88d30	313	311	E1600313	Evelyn Robinson	Evelyn	Davis	\N	5/10/1944	76 yrs	Female	\N	\N	601-454-6474	\N	5123 Sun Valley	Jackson	MS	39206	1600
69d291d3-aee7-401a-9f0d-f7a0e82d45aa	489	1029	J1600489	Justin	\N	Moody	\N	8/3/1983	37 yrs	Male	\N	\N	601-373-9044	\N	5900 Seven Springs Rd.	Raymond	MS	39154	1600
200263cc-bebf-4430-867a-40871a663d93	1492	1488	K16001492	Keveon	\N	Spann	\N	11/3/2000	20 yrs	Male	\N	\N	601-376-7291	\N	1710 Florence Ave.	Jackson	MS	39204	1600
ac4b385f-7b33-4698-bb01-64be9af7f0b1	889	887	R1600889	Raymond	\N	Carter	\N	7/27/1951	69 yrs	Male	\N	\N	601-925-4715	\N	1100 Warner Jordan Dr.	Clinton	MS	39056	1600
a8306e7f-f908-4924-b70e-b243b257630a	198	196	J1600198	Jacquelyn Hayes	Jacquelyn	Hampton	\N	8/26/1951	69 yrs	Female	jlinkads@bellsouth.net	\N	601-594-1844	601-594-1844	50 Robinwood Pl.	Jackson	MS	39211	1600
1ab7dbc8-f24d-4e9c-8089-38d11ce675f6	3352	3343	E16003352	Ethan	\N	Franklin	\N	10/20/2008	12 yrs	Male	\N	\N	601.347.9145	\N	650 Windward Lane	Richland	MS	39218	1600
fd009b75-dc5c-4390-b43d-d85799ef3e5b	199	197	J1600199	James	\N	Hampton III	\N	7/22/1979	41 yrs	Male	jih3email@gmail.com	\N	601-983-7005	\N	50 Robinwood Pl.	Jackson	MS	39211	1600
6327b2cc-10f2-43b1-b77f-768e914af475	200	198	A1600200	Angel Shamille	Angel	Hampton	\N	2/22/1977	44 yrs	Female	\N	\N	601-983-7005	\N	214 Camelot Way	Brandon	MS	39047	1600
3b0938c5-d0dd-4536-9382-1164887ff109	3635	\N	C16003635	Christopher	\N	Langford	\N	11/1/1986	34 yrs	Male	\N	\N	601-966-9700	\N	824 Planters Point Dr	Canton	MS	39046	1600
52116bc8-63c0-4a1b-b9cf-790346bf9d12	203	902	C1600203	Claudia	\N	Henderson	\N	7/19/1957	63 yrs	Female	claudiahend@gmail.com	\N	769-251-1100	601-942-0044	410 Justin Cove	Byram	MS	39272	1600
f62cd9ca-0a40-446e-b3bb-08fba83342c3	205	902	K1600205	Krista	\N	Henderson	\N	6/12/1984	36 yrs	Female	\N	\N	769-251-1100	\N	410 Justin Cove	Byram	MS	39272	1600
04afe841-81af-46cb-bd06-25f01af0e56b	208	206	J1600208	John	\N	Higgins	\N	2/26/1961	60 yrs	Male	heyque@aol.com	\N	601-856-5654	601-209-7356	117 Elizabeth Ave	Madison	MS	39110	1600
7cd80d9e-74da-4c30-b33e-2913e964e32f	539	537	T1600539	Tamara	\N	Robinson	\N	5/2/1968	52 yrs	Female	\N	\N	601-906-0814	\N	127 Victoria Place	Brandon	MS	39042	1600
fe280ba3-e532-4923-993d-9588a5943b5c	515	513	A1600515	Adriane	\N	Randolph	\N	1/2/1900	121 yrs	Female	\N	\N	601-372-8160	\N	1342 Hair St.	Jackson	MS	39204	1600
aa831263-690d-4807-990c-f3065d07db2b	2130	376	A16002130	Aaliyah	\N	Horn	\N	11/6/2006	14 yrs	Female	\N	\N	601-750-9431	\N	3535 Highway East	Pearl	MS	39208	1600
e20cc259-b74d-4b5d-909d-34ffd000fd79	892	3593	B1600892	Bobby	\N	Pamplin II	\N	11/17/1991	29 yrs	Male	\N	\N	601-922-7025	\N	3420 Dundee Lane	Jackson	MS	39212	1600
5d35b37e-1f9b-4075-8130-9e5ed0ce1bce	209	206	D1600209	Daphne Monix	Daphne	Higgins	\N	6/24/1961	59 yrs	Female	daphne.higgins@aol.com	\N	601-856-5654	601-209-7355	117 Elizabeth Ave	Madison	MS	39110	1600
f343f979-9ac3-487c-8618-ad75a34ebc00	1525	1524	F16001525	Forrest	\N	Davis	\N	10/12/1999	21 yrs	Male	\N	\N	601-421-3693	\N	601 Cedarhurst Rd.	Jackson	MS	39206	1600
3fc32c8e-612a-4e46-ba91-b00723397fb8	214	212	C1600214	Catherine	\N	James	\N	9/22/1948	72 yrs	Female	c2013james@gmail.com	\N	601-981-7747	601-842-7055	837 Buttonwood	Jackson	MS	39206	1600
9cb624ac-f858-48b0-9838-1640175dc7b9	215	212	M1600215	Michael Anthony	Micheal	James	\N	1/10/1983	38 yrs	Male	\N	\N	601-981-7747	601-497-9842	837 Buttonwood	Jackson	MS	39206	1600
0af11dfa-71f9-46ff-a3ea-a01e2c96cfa2	732	730	W1600732	William	\N	Wheeler	\N	12/29/1900	120 yrs	Male	\N	\N	601-503-3711	\N	103 Grayhawk Cove	Madison	MS	39110	1600
0e480dca-ca47-438f-8c17-c7b27c44cc07	216	212	A1600216	Alicia Morzarena	Alicia	James	\N	6/1/1984	36 yrs	Female	aliciajames6184@gmail.com	\N	601-981-7747	601-212-2408	837 Buttonwood	Jackson	MS	39206	1600
bc9a994e-bff3-4453-abd3-831601b38a46	365	363	W1600365	Willie E.	Willie	Hill	\N	4/29/1948	72 yrs	Male	\N	\N	601-376-0845	\N	121 Waxwing Dr.	Jackson	MS	39212	1600
d1fbe6da-4c60-490c-95a2-93ce6d1be402	217	215	V1600217	Vernon	\N	Jasper	\N	2/10/1950	71 yrs	Male	vernonjasper@comcast.net	\N	601-260-5585	601-260-5585	4669 Norway Dr.	Jackson	MS	39206	1600
6868401a-d73e-4286-bc2f-a430ba15629b	1532	486	A16001532	Ariel	\N	Griffin	\N	1/8/1998	23 yrs	Female	\N	\N	601-954-1860	\N	5104 Brookleigh Drive	Byram	MS	39272	1600
27a6025c-d4ae-4882-84f2-b5d48d040a52	219	215	J1600219	Jarrett	\N	Jasper	\N	4/3/1981	40 yrs	Male	\N	\N	601-981-4089	601-942-5852	4669 Norway Dr.	Jackson	MS	39206	1600
61fbb6ac-c551-4f33-b165-990e83055105	220	218	D1600220	Darryl	\N	Jenkins	\N	6/10/1967	53 yrs	Male	djenkins120@gmail.com	\N	601-201-2895	601-201-2895	140 Glenwild Trl.	Canton	MS	39046	1600
fbf1e79a-1a95-42b2-8dd7-43598b04f8f2	962	960	B1600962	Bobbie	\N	Lowe	\N	8/15/1952	68 yrs	Female	\N	\N	601-372-8160	\N	1235 Marydale Dr.	Jackson	MS	39212	1600
b77213e9-5d22-448c-8f50-3557dd9718eb	221	218	S1600221	Sandra	\N	Jenkins	\N	11/13/1967	53 yrs	Female	sjenks1908@gmail.com	\N	601-201-2895	601-201-5176	140 Glenwild Trl.	Canton	MS	39046	1600
44ce4515-c491-4100-9a73-d7c076bd5b43	1351	1349	T16001351	Timothy W.	Timothy	Rush II	\N	7/26/1992	28 yrs	Male	\N	\N	601-572-7427	\N	131 Marshall Drive	Jackson	MS	39212	1600
e8924e56-d821-4abc-86b7-91bb20a76852	223	220	M1600223	Mildred B.	Mildred	Kelley	\N	10/3/1935	85 yrs	Female	mbkelley10@aol.com	\N	601-355-1317	601-966-1343	533 Fredrica Ave.	Jackson	MS	39209	1600
976fa430-0d61-4d88-aea4-c6258ab1b589	231	229	J1600231	Jacob	\N	McEwen	\N	4/4/1952	69 yrs	Male	mcewen04@comcast.net	\N	601-372-5753	601-842-0023	307 Swan Lake Dr.	Jackson	MS	39212	1600
720ba0e1-50ac-4399-83c7-cf8e941200c2	1650	465	T16001650	Taylor	\N	Washington	\N	4/18/2002	18 yrs	\N	\N	\N	601-203-9664	\N	1832 Northwood Circle	Jackson	MS	39213	1600
f0a4017a-a633-497b-b89a-cbe3d1c73f29	232	229	S1600232	Sandra	\N	McEwen	\N	12/24/1952	68 yrs	Female	svmcewen03-12@outlook.com	\N	601-372-5753	601-942-9604	307 Swan Lake Dr.	Jackson	MS	39212	1600
ea80cb64-097d-4962-84de-c082a6fea7c1	374	372	G1600374	George	\N	Hood Sr.	\N	11/30/1960	60 yrs	Male	debbie.hood@att.net	\N	601-213-2420	601-454-5471	1448 Forbes Drive	Jackson	MS	39272	1600
b44a9166-4d06-4062-b40d-b096988c49e8	366	363	R1600366	Roceda C	Roceda	Hill	\N	8/9/1957	63 yrs	Female	rocedahill@yahoo.com	\N	601-376-0845	\N	121 Waxwing Dr.	Jackson	MS	39212	1600
05ef68d9-ea7f-4060-a3a1-3446df044354	233	231	T1600233	Terrance Jacob	Terrance	McEwen	\N	7/28/1982	38 yrs	Male	terrancejmcewen@gmail.com	\N	601-209-9411	\N	104 Buckeye Drive	Madison	MS	39110	1600
c20de44c-b197-435f-a166-13f85cdcb2f0	1996	1020	B16001996	Blake	\N	Hansberry	\N	12/13/2007	13 yrs	Male	\N	\N	601-373-9633	\N	118 Rowan Oak Place	Terry	MS	39170	1600
21030eff-f9ed-432d-bf15-b7aed11650bb	1628	2016	A16001628	Adalis	\N	Williams	\N	10/2/1996	24 yrs	Female	\N	\N	601-665-9254	\N	3266 Fleetwood Dr.	Jackson	MS	39212	1600
d19e9119-9d96-4afc-bfeb-3066fac77826	234	232	S1600234	Shaun Rashad	Shaun	McEwen	\N	5/25/1986	34 yrs	Male	shaun39212@yahoo.com	\N	601-862-3068	\N	307 Swan Lake Dr.	Jackson	MS	39212	1600
082e09b1-d526-45d5-aea8-f3c7f9f75250	241	239	M1600241	Margarette	\N	Meeks	\N	4/19/1962	58 yrs	Female	mlfmeeks@gmail.com	\N	601-346-7244	\N	1222 Wooddell Drive	Jackson	MS	39212	1600
6c5d0393-1153-4195-b4e6-17387d25b280	244	242	J1600244	John	\N	Morris	\N	9/19/1939	81 yrs	Male	fgmorris03@gmail.com	\N	601-981-8330	601-966-0232	5914 Canterbury Rd	Jackson	MS	39206	1600
b00fe68c-802a-44c7-bbbe-b5cf1a2c3fbc	2136	2134	M16002136	Monturia	\N	Watkins	\N	2/8/1983	38 yrs	Female	\N	\N	601-376-6382	\N	1314 Woodell Dr.	Jackson	MS	39212	1600
9e3bb76f-1b17-41c1-a1b1-63fe92fcf612	245	242	F1600245	Frances Greer	Frances	Morris	\N	10/12/1942	78 yrs	Female	fgmorris03@gmail.com	\N	601-981-8330	\N	5914 Canterbury Rd	Jackson	MS	39206	1600
8b017948-e304-4956-80c5-0ffe1ec7b777	246	242	J1600246	John	\N	Morris II	\N	5/25/1973	47 yrs	Male	\N	\N	601-209-0512	\N	125 Parkfield Dr	Madison	MS	39110	1600
a2b4dd15-e0c7-40e8-8954-9b25f9ddf0da	248	242	M1600248	Mitzi	\N	Morris	\N	12/27/1983	37 yrs	Female	earlnpearl@aol.com	\N	601-981-8330	\N	5914 Canterbury Rd	Jackson	MS	39206	1600
bd377372-440c-413f-a8de-7cd4e48f70d5	249	3594	B1600249	Bobby	\N	Pamplin	\N	10/6/1962	58 yrs	Male	bobbypamplin@gmail.com	\N	601-922-7025	601-955-7437	3420 Dundee Lane	Jackson	MS	39212	1600
dc84c174-1657-4047-ae71-5b748a0943a6	788	786	E1600788	Earnestine	\N	Young	\N	9/3/1900	120 yrs	Female	\N	\N	601-373-7809	\N	204 Freemyer Dr.	Byram	MS	39272	1600
66392131-5cba-4e0b-be69-c87bced9558e	250	3593	J1600250	Jessie	\N	Pamplin	\N	3/24/1962	59 yrs	Female	suzypamp@yahoo.com	\N	601-922-7025	601-954-7083	3420 Dundee Lane	Jackson	MS	39212	1600
77f9031c-3ba5-4c2f-8812-cb16e09d5367	1045	1043	W16001045	Willie	\N	McGill	\N	2/4/1953	68 yrs	Male	\N	\N	601-238-3257	\N	334 Summerville Drive	Madison	MS	39110	1600
0f00b339-6b7d-4086-b54a-d16784e0f539	256	254	L1600256	Larry	\N	Bridges	\N	10/31/1955	65 yrs	Male	lbridges1@bellsouth.net	\N	601-927-3498	\N	1533 Fairwood Dr.	Jackson	MS	39213	1600
1beebc9f-7d41-49ef-8c8b-98bc14d21d44	451	449	L1600451	Louise	\N	Marshall	\N	4/10/1927	94 yrs	Female	\N	\N	601-906-5258	\N	1707 Morehouse	Jackson	MS	39204	1600
6e87f55d-ad52-4509-b596-796c3346da4a	264	262	L1600264	Lindsey	\N	Brown	\N	12/19/1989	31 yrs	Male	\N	\N	601-201-5631	\N	53 Northtown Dr.\nApt. 31W	Jackson	MS	39211	1600
12e39ecd-7499-4ccd-9c7c-c3a88b1d23f4	634	632	J1600634	John	Danny	Staffney	\N	7/20/1963	57 yrs	Male	stf438@yahoo.com	\N	601-353-5146	601-397-0610	133 Hemlock Ln.	Madison	MS	39110	1600
5a62817f-5010-4c2f-8ac8-12245c850467	275	882	L1600275	Lenita Bryant	Lenita	Knight	\N	7/4/1967	53 yrs	Female	lenitaknight@bellsouth.net	\N	601-201-3027	601-259-9833	126 Brisco Street	Madison	MS	39110	1600
dd177fdc-fdef-47d0-ad6b-921e5f05cc56	1065	1063	M16001065	Marilyn	\N	Brumfield	\N	12/19/1958	62 yrs	Female	Brum9@bellsouth.net	\N	601-922-4305	\N	1009 Westhaven Blvd.	Jackson	MS	39209	1600
53d11940-b7b5-45b0-8cd8-c61a7ae61dc0	279	277	J1600279	Jacqueline	\N	Butler	\N	9/11/1950	70 yrs	Female	jbutler03@bellsouth.net	\N	601-366-6628	601-672-3158	4736 Village Dr	Jackson	MS	39206	1600
41824eec-e5d3-4f10-a2e4-51f803f0a6c8	281	278	J1600281	Josephine	\N	Byas	\N	4/22/1950	70 yrs	Female	\N	\N	601-353-2328	\N	538 Fredrica Ave	Jackson	MS	39209	1600
cd892c1f-c8b7-45f1-9f34-3140bb8179fa	292	290	J1600292	Jimmy	Jimmy	Coleman	Jimmy L Coleman	12/13/1963	57 yrs	Male	jlcoleman41@yahoo.com	\N	601-201-1906	601-201-1906	5633 Dogwood Trail	Jackson	MS	39212	1600
7ce23290-b575-455b-b0c8-11dfeb332c92	1491	1488	K16001491	Koqawn	\N	Spann	\N	1/2/1999	22 yrs	Male	\N	\N	601-376-7291	\N	1710 Florence Ave.	Jackson	MS	39204	1600
4b5eb2db-2f2f-4462-a992-0969c079df3f	873	457	J1600873	John  Dozier	John	McCallum	\N	8/20/1980	40 yrs	Male	\N	\N	601-925-8223	\N	550 Sunny Orchard Lane	Clinton	MS	39056	1600
b6df0d3d-f01a-447f-9c62-050ce5e47e11	293	290	J1600293	Jonora Nita	Jonora	Coleman	\N	5/1/1964	56 yrs	Female	jrcoleman1992@yahoo.com	\N	601-201-1906	601-201-0339	5633 Dogwood Trail	Jackson	MS	39212	1600
f4145622-b649-41e4-be8b-d84d11dda0d7	295	292	E1600295	Evelia	\N	Collins	\N	5/12/1971	49 yrs	Female	evelia1022@gmail.com	\N	601-260-5563	\N	110 Ellicot Burn	Clinton	MS	39056	1600
4cf5b472-fee6-4fe8-9aa5-ce8d7084c58f	300	1522	M1600300	Marian	\N	Covington	\N	6/30/1936	84 yrs	Female	\N	\N	601-355-2239	\N	1047 Pecan Blvd.	Jackson	MS	39209	1600
9776fe45-c7e0-4f89-ad30-c7db86d1b9a5	304	301	E1600304	Elois	\N	Crouther	\N	2/12/1937	84 yrs	Female	\N	\N	601-362-6877	\N	2430 Queensroad Ave.	Jackson	MS	39213	1600
c7bd1f42-d7eb-44ec-8690-22b37208baeb	317	315	S1600317	Shirley	\N	Davis	\N	5/23/1957	63 yrs	Female	sdavis1957@att.net	\N	601-373-7006	601-954-2400	309 South Haven Dr.	Jackson	MS	39272	1600
6bd9fa24-1e60-4a30-bdbe-f538a848ca7a	1626	2016	S16001626	Shamiar	\N	Williams	\N	9/24/1990	30 yrs	Female	\N	\N	601-665-9254	\N	3266 Fleetwood Dr.	Jackson	MS	39212	1600
7f94b65a-1cbf-4402-b369-3c1a312c4e31	318	316	A1600318	Alfranso	\N	Davis	\N	8/19/1972	48 yrs	Male	alfransodavis@gmail.com	\N	601-540-0941	601-540-0941	4059 Henderson Rd.	Byram	MS	\N	1600
1a508ef6-e139-4951-8abc-6ce9fe6d329e	528	525	L1600528	Lenora	\N	Reed	\N	12/28/1933	87 yrs	Female	LenoraReed@Bellsouth.net	\N	601-353-9977	601-955-6500	1612 Florence Ave	Jackson	MS	39204	1600
269d2eb8-21d9-4ec8-af6c-af271ac0616c	324	322	C1600324	Charles W.	Charles	Dukes Sr.	\N	11/26/1948	72 yrs	Male	bigdaddyjsu@gmail.com	\N	601-346-6181	601-668-5725	217 Northbrook Circle	Jackson	MS	39212	1600
612429cb-86d9-49b9-89b1-39c84360b0c9	325	322	D1600325	Derra	\N	Dukes	\N	9/3/1949	71 yrs	Female	derra.dukes@yahoo.com	\N	601-346-6181	601-668-5725	217 Northbrook Circle	Jackson	MS	39212	1600
6d90a41c-196f-4070-b7ec-6ba47b656f7f	342	340	R1600342	Robert	\N	Green Jr.	\N	7/11/1950	70 yrs	Male	workinggreen68@hotmail.com	\N	601-982-0729	601-953-0117	5740 Kirkley Dr.	Jackson	MS	39206	1600
a8e8b9f1-a8c1-438a-9d97-5601e1d617ee	343	340	A1600343	Audrey	\N	Green	\N	10/15/1950	70 yrs	Female	\N	\N	601-982-0729	601-968-7886	5740 Kirkley Dr.	Jackson	MS	39206	1600
dd4fe26e-3eeb-4edb-9899-e1bac1c5069e	970	528	C1600970	Chanda	\N	Reeves	\N	5/3/1994	26 yrs	Female	\N	\N	601-371-6454	\N	600 S. Springlake Circle	Terry	MS	39170	1600
d9087f93-0d72-45f4-9cc9-2e5becdbf3ce	1332	1330	K16001332	Kelvin	\N	Harris	\N	7/12/1972	48 yrs	Male	\N	\N	601-622-3806	\N	4952 Brookwood Place	Jackson	MS	39272	1600
94639294-e7f4-4061-a658-4f077c83d628	344	342	T1600344	Toroski	\N	Green	\N	1/16/1977	44 yrs	Male	togreen77@yahoo.com	\N	601-896-6199	\N	112 Rollingwood Drive	Jackson	MS	39211	1600
bc91b70a-458f-4f82-a7e4-d047f9c046e4	971	1311	A1600971	Asiah	\N	Ford	\N	7/31/1996	24 yrs	Female	\N	\N	601-405-1311	\N	445 Hillandale Drive	Jackson	MS	39212	1600
16d03a6a-0a15-4700-921e-67c9f7c3c0ab	351	349	A1600351	Alonzo N.	Alonzo	Hamilton Jr.	\N	2/5/1958	63 yrs	Male	ichthyguy@yahoo.com	\N	601-372-9856	601-201-2723	105 Glen Iris Place	Jackson	MS	39204	1600
82c34240-2999-473a-a12c-6b5af258596b	721	719	S1600721	Shambani	\N	Watts	\N	2/12/1968	53 yrs	Male	\N	\N	601-573-9365	\N	1704 Florence Ave.	Jackson	MS	39204	1600
412d0cba-2521-4b5c-9a74-8d1b764eec58	978	976	E1600978	Ella Aretha	Ella	Cain	\N	12/13/1972	48 yrs	Female	\N	\N	\N	\N	1415 Everett Street\napt A-1	Jackson	MS	39204	1600
50c76368-ec57-4dd2-8bba-4932d9f6a3b5	356	354	E1600356	Emma L.	Emma	Harris	\N	4/18/1951	69 yrs	Female	sparklejimhill@yahoo.com	emharr6@aol.com	601-672-6385	601-473-5571	926 Bullrun Drive	Byram	MS	39272	1600
825f186b-0a52-478b-9c5e-6246405489aa	359	357	L1600359	LaToya	\N	Hart	\N	6/28/1977	43 yrs	Female	hart95@hotmail.com	hartlatoya@gmail.com	601-942-3372	\N	PO Box 75505	Jackson	MS	39282	1600
c455f03b-5698-41d0-899b-b6c7d2195dcb	375	372	D1600375	Debbie	\N	Hood	\N	8/10/1962	58 yrs	Female	debbiehood87@gmail.com	\N	601-213-2420	\N	1448 Forbes Drive	Jackson	MS	39272	1600
0134d63d-b99c-4d12-9288-ab76071b87a6	378	376	V1600378	Vickie	\N	Horn	\N	3/28/1964	57 yrs	Female	zan4me@yahoo.com	\N	601-750-9431	\N	3535 Highway East	Pearl	MS	39208	1600
38bc96d7-b7e9-4e25-aa48-6a0232cc9b80	386	384	N1600386	Noel Jackson	Noel	Bogan	\N	12/15/1955	65 yrs	Female	bogan4445@aol.com	\N	601-845-8778	601-259-5578	691 Thomasville Rd.	Florence	MS	39073	1600
cd85bfdf-6473-4391-9533-2e9fd03c0068	397	395	L1600397	LaDonna D.	LaDonna	Jacobs	\N	3/3/1968	53 yrs	Female	ljacobs@memexcu.com	\N	601-954-3286	601-201-4837	202 Dona Ave.	Jackson	MS	39212	1600
ed6f0460-ca7a-4faa-89d9-330708344511	407	405	R1600407	Rahsaan	\N	Johnson	\N	8/13/1981	39 yrs	Male	Johnson07@yahoo.com	\N	(601) 750--5756	601-896-1440	313 Brookside Cove	Terry	MS	39170	1600
8a1669ab-e2db-45fe-9ec3-f4ce115effeb	409	407	B1600409	Bertha	\N	Johnson	\N	12/20/1956	64 yrs	Female	bjohns8@entergy.com	\N	601-259-6077	\N	500 Avalon Way Apt. #307	Brandon	MS	39047	1600
2878666e-a489-492b-84c6-05c5b6fc78f1	426	423	S1600426	Shirley Woods	Shirley	Johnson	\N	12/25/1949	71 yrs	Female	\N	\N	601-360-8336	\N	1402 Jones St	Jackson	MS	39204	1600
a4df13ee-c053-46d6-bdde-112e2502c714	434	432	S1600434	Shannan	\N	Jones	\N	2/11/1969	52 yrs	Female	\N	\N	601-372-7338	601-918-2004	34 Brock Dr.	Jackson	MS	39272	1600
87ed8936-bc24-4b3d-856f-a3341c43b0a1	441	439	M1600441	Marguerite	\N	Love	\N	3/5/1931	90 yrs	Female	\N	\N	601-981-3270	\N	4750 Methodist Farm Road	Jackson	MS	39213	1600
9162b34c-a77d-4409-bd3f-e9cfbd6faa20	610	608	H1600610	Houston A.	Houston	Smith	\N	11/21/1942	78 yrs	Male	\N	\N	601-927-3097	601-927-3097	549 Lexington Ave.	Jackson	MS	39209	1600
54185e35-238e-45f5-9d50-3d78a3d751f5	1380	1020	D16001380	Darius	\N	Wilson	\N	3/10/1983	38 yrs	Male	\N	\N	601-373-9633	\N	118 Rowan Oak Place	Terry	MS	39170	1600
924fb45e-9e5b-45eb-bfe5-82d546eedb56	569	566	B1600569	Betty	\N	Sexton	\N	6/28/1958	62 yrs	Female	sexamelv@yahoo.com	\N	601-953-4160	\N	2918 Shelia Dr.	Jackson	MS	39209	1600
d7d64665-d5e6-4535-95bc-bdea7f3b6b59	445	443	O1600445	Onnie T.	Onnie	Madison	\N	2/27/1966	55 yrs	Female	onnie.mad906@gmail.com	\N	601-906-1814	601-906-1814	313 Heritage Place	Jackson	MS	39212	1600
f4ac720e-c88f-4fdf-8d96-cb265b1d5448	1612	1311	C16001612	Chloe	\N	Nash	\N	11/7/2003	17 yrs	Female	\N	\N	601-405-1311	\N	445 Hillandale Drive	Jackson	MS	39212	1600
0e75edf6-8ef4-4c61-b79e-9bdcda77301f	446	443	Q1600446	Quentin Sherrod	Quentin	Terrell	\N	3/1/1989	32 yrs	Male	\N	\N	601-906-1814	\N	313 Heritage Place	Jackson	MS	39212	1600
636ebb3e-36e9-4642-b17b-167497b6a815	453	451	J1600453	Julius	\N	Martin Jr.	\N	8/23/1960	60 yrs	Male	jmj82360@aol.com	\N	601-982-7846	601-668-5700	793 Jasmine Court	Jackson	MS	39206	1600
417aefdb-feb3-4121-9a7c-64720225302d	460	457	B1600460	Berlena C.	Berlena	McCallum	\N	10/24/1954	66 yrs	Female	berlena.mccallum@yahoo.com	\N	601-925-8223	601-832-2114	550 Sunny Orchard Lane	Clinton	MS	39056	1600
adae84bd-d4b4-4955-af4b-bb94293077e9	467	465	M1600467	Meredith Menjonne	Meredith	McGee	\N	8/5/1970	50 yrs	Female	\N	\N	601-203-9664	\N	1832 Northwood Circle	Jackson	MS	39213	1600
fb88d18c-333f-40bf-bb3d-453b4af4e680	793	791	F1600793	Frank A.	Frank	Yates	\N	2/14/1944	77 yrs	Male	fyates44@aol.com	\N	601-936-3755	601-940-5471	722 Woodrun Dr.	Pearl	MS	39208	1600
b0d8f893-ba4e-4f04-908e-8b9a776e2555	471	469	C1600471	Calvin	\N	Michael Sr.	\N	4/16/1900	120 yrs	Male	clvnmichael@gmail.com	\N	601-925-5037	601-750-2240	104 Trace Wood Cove	Clinton	MS	39056	1600
4d136522-0771-4774-9983-8a4b53707571	637	634	T1600637	Tarsha	\N	Staffney	\N	3/16/1979	42 yrs	Female	\N	\N	601-353-5146	\N	1715 Florence Ave.	Jackson	MS	39204	1600
c7c1b8a6-71e7-4b60-9730-088a774b313b	472	469	S1600472	Shellie C.	Shellie	Michael	\N	11/11/1957	63 yrs	Female	michaelscm@comcast.net	\N	601-925-5037	\N	104 Trace Wood Cove	Clinton	MS	39056	1600
27765f67-8e8f-4cd1-ae93-f63896dd60d7	1629	2016	E16001629	Emiyah	\N	Williams	\N	12/3/2002	18 yrs	Female	\N	\N	601-665-9254	\N	3266 Fleetwood Dr.	Jackson	MS	39212	1600
46de6164-98e5-4a41-955d-509cde69d034	1844	2169	V16001844	Vincent	\N	Evans Jr.	\N	12/2/1985	35 yrs	Male	\N	\N	769.220.5795	\N	4308 Newpost Road	Clinton	MS	39212	1600
9163427c-5bf7-4cf7-817f-6392fe3e8c8c	475	473	J1600475	Jerry	\N	Mitchell Sr.	\N	12/26/1949	71 yrs	Male	jerry_mitchell@bellsouth.net	\N	601-352-1189	601-668-5061	2834 Hemingway Cir.	Jackson	MS	39209	1600
2ed557ef-6971-4e7b-a328-b90a31faf7f2	476	473	Y1600476	Yvette	\N	Mitchell	\N	6/29/1950	70 yrs	Female	lmitchell2834@gmail.com	\N	601-352-1189	601-826-7304	2834 Hemingway Cir.	Jackson	MS	39209	1600
6ff1b511-361a-4e34-810e-b90d750ce462	487	1029	D1600487	Debra Moody	Debra	McGee	\N	7/17/1960	60 yrs	Female	debramcgee@bankplus.net	\N	601-373-9044	\N	5900 Seven Springs Rd.	Raymond	MS	39154	1600
b11825da-bc0d-410e-b897-5ef6971dd038	488	486	T1600488	Tanesha Vonshay	Tanesha	Moody	\N	12/15/1977	43 yrs	Female	tanesha64@gmail.com	\N	601-954-1860	\N	5104 Brookleigh Drive	Byram	MS	39272	1600
459035c6-caf9-473a-9ffa-fd03a4c14189	490	484	V1600490	Vanette	\N	Montgomery	\N	12/2/1963	57 yrs	Female	vmonty877@gmail.com	\N	601-473-6265	\N	738 Cherry Stone Dr.	Clinton	MS	39056	1600
c890d586-e8d1-4bc9-8e3a-e9440c1ee213	492	484	J1600492	Justin	\N	Montgomery	\N	3/8/1988	33 yrs	Male	\N	\N	601-473-6265	\N	738 Cherry Stone Dr.	Clinton	MS	39056	1600
d11bdfdc-8e8a-4ec1-bb11-45cc9414d7c6	645	642	R1600645	Rufus	\N	Tate Sr.	\N	5/31/1948	72 yrs	Male	\N	\N	601-355-5232	\N	2616 Hemingway Circle	Jackson	MS	39209	1600
6077b061-bcb3-406e-b6a0-373bcf116e22	500	498	R1600500	Ruth	\N	Mosley	\N	2/19/1943	78 yrs	Female	rsmosley.213@gmail.com	\N	601-373-4442	601-942-5409	600 Park Grove Dr.	Katy	TX	77450	1600
a2970662-a1cf-4901-bac3-2149e7130ef7	890	887	B1600890	Bertha	\N	Carter	\N	6/18/1951	69 yrs	Female	\N	\N	601-925-4715	\N	1100 Warner Jordan Dr.	Clinton	MS	39056	1600
0c85c12a-7f0b-47c2-8145-28639dd4c6de	690	688	T1600690	Tara Bryant	Tara	Walker	\N	5/16/1957	63 yrs	Female	taralaw82@yahoo.com	\N	601-613-4443	\N	905 West Ridge Drive	Jackson	MS	39209	1600
e4a3c9c6-1413-4b2f-93b7-215a6af7b6a9	924	469	C1600924	Cole	\N	Michael	\N	6/4/1989	31 yrs	Male	\N	\N	601-925-5037	\N	104 Trace Wood Cove	Clinton	MS	39056	1600
5e40897d-af4e-4a80-9001-4ae6b8d8cf51	506	504	C1600506	Calvin D.	Calvin	Ousby Sr.	\N	10/25/1959	61 yrs	Male	cousby@cbenterprise.org	\N	601-853-1108	601-238-7899	P.O. Box 2816	Madison	MS	39130	1600
cd18d6f2-c305-456e-8695-e7f5a1e928ad	507	504	B1600507	Barbara Russ	Barbara	Ousby	\N	8/31/1966	54 yrs	Female	cbousby@aol.com	\N	601-853-1108	601-238-9129	P.O. Box 2816	Madison	MS	39130	1600
6b1ada5e-9510-4eb4-bfbb-c5f87975cf17	521	519	L1600521	Lillie Marie	Lillie	Ransom	\N	5/10/1974	46 yrs	Female	\N	\N	601-937-2036	\N	2419 Latimer Avenue	Jackson	MS	39209	1600
f6e7cd5c-8838-454b-b23d-c50e279f341a	723	722	L1600723	La Tanya	\N	Watts	\N	3/21/1956	65 yrs	Female	\N	\N	601-949-5559	\N	1454 Sullen Ave	Jackson	MS	39213	1600
415861bd-15e8-4303-8b12-a87731d0167b	716	714	S1600716	Susie Mae Williams	Susie	Watson	\N	3/10/1956	65 yrs	Female	sweetsue267@gmail.com	\N	601-948-5374	601-540-4393	4533 Elfin St.	Jackson	MS	39209	1600
33376699-12ac-4dff-bb13-ba4c22efd263	530	528	C1600530	Carlton W	Carlton	Reeves	\N	4/11/1964	57 yrs	Male	carltonwreeves@gmail.com	carlton_reeves@mssd.uscourts.gov	601-371-6454	601-213-9599	600 S. Springlake Circle	Terry	MS	39170	1600
7a3b8279-fcd4-4875-9b6c-4341829bef61	536	534	R1600536	Robert	\N	Robinson Sr.	\N	2/21/1951	70 yrs	Male	\N	\N	601-366-0681	601-573-1560	518 Beasley Rd.	Jackson	MS	39206	1600
069f2555-706d-49c0-bd02-268849927436	1541	1539	D16001541	Derrick	\N	Johnson	\N	8/16/1974	46 yrs	Male	johnson.derrick41@yahoo.com	\N	601-665-3554	\N	303 Shadow Wood Dr.	Clinton	MS	39056	1600
ffc3c96f-d6b4-44dc-ace3-3ed0974e3dd2	537	1361	S1600537	Sharon Bridges	Sharon	Robinson	\N	3/8/1943	78 yrs	Female	slynrobinson93@gmail.com	\N	601-982-0324	\N	973 Watkins Place	Jackson	MS	39206	1600
99ca1222-6e58-4891-976f-438af7a842ca	1349	206	J16001349	John	\N	Higgins II	\N	3/28/1996	25 yrs	Male	M.c.Boi@yahoo.com	\N	601-856-5654	601-209-8553	117 Elizabeth Ave	Madison	MS	39110	1600
41ab308e-7fbd-4ad3-8dee-d928cefd3ba4	1393	1391	P16001393	Penny	\N	Hedrick	\N	10/22/1963	57 yrs	Female	pennyhedrick.52@gmail.com	\N	601-497-3795	\N	2846 Fallbrook Dr.	Jackson	MS	39212	1600
d2788153-c9af-4677-a232-7d29215d85a1	540	538	T1600540	Thomas J.	TJ	Robinson Sr.	\N	12/2/1900	120 yrs	Male	tj_robinson2004@yahoo.com	\N	601-981-4793	601-454-5512	231 Valley North Blvd.	Jackson	MS	39206	1600
7cd41201-8583-4b39-85ec-56fc01cf1c98	735	733	L1600735	Louis	\N	Wiggins	\N	2/20/1950	71 yrs	Male	louiswggns@gmail.com	\N	601-981-6007	\N	306 Lake of Pine Dr.	Jackson	MS	39206	1600
46e0bd0e-c254-40ab-9299-d931b10c7653	739	737	C1600739	Carolyn A.	Carolyn	Williams	\N	2/15/1955	66 yrs	Female	\N	\N	601-957-6996	\N	5862 Deer Trail	Jackson	MS	39211	1600
45c51d63-c474-4b58-b8bf-b4ee203a84c7	742	739	N1600742	Nadia K.	Nadia	Williams	\N	6/11/1982	38 yrs	Female	\N	\N	601-572-4445	\N	768 Jasmine Ct.	Jackson	MS	39206	1600
1b522293-e798-48a6-b9b3-89e2c3da24f5	1422	642	J16001422	Ja'shaun	\N	Tate	\N	2/28/1996	25 yrs	Male	\N	\N	601-355-5232	\N	2616 Hemingway Circle	Jackson	MS	39209	1600
132a9d52-1e56-424b-ba81-945bcca9a317	995	995	K1600995	Kendrall L.	Kendrall	Prowell	\N	1/18/1989	32 yrs	Female	\N	\N	601-487-6682	\N	100 Cedarwood Drive	Jackson	MS	39212	1600
d33a6f6e-5d45-4a2f-88c2-02ee3ac49043	762	758	K1600762	Kynesha R.	Kynesha	Williams	\N	9/14/1981	39 yrs	Female	\N	\N	404-694-4064	\N	1640 Terry Mill Lane	Grayson	GA	30017	1600
a4b70e6f-55b4-45dd-ab48-0ebf11eaf7b8	775	773	J1600775	Jessie Loach	Jessie	Willis	\N	7/11/1900	120 yrs	Female	\N	\N	601-366-3883	\N	2420 Queensroad Ave.	Jackson	MS	39213	1600
fd36bdcc-820b-41b1-b00c-11d4ab75038d	753	751	J1600753	James	\N	Williams	\N	1/14/1971	50 yrs	Male	james.williams540@bellsouth.net	\N	601-366-9819	\N	2846 Marion Dunbar St.	Jackson	MS	39213	1600
382d8463-0077-4ea8-b2a3-62b64cb1e3e8	776	773	J1600776	James I.(Jimmy)	James	Willis	\N	7/22/1958	62 yrs	Male	\N	\N	601-366-3883	\N	2420 Queensroad Ave.	Jackson	MS	39213	1600
73e6e387-84e0-43f2-b257-8dd3a7deea61	748	746	E1600748	Emma	\N	Williams-Holmes	\N	6/18/1965	55 yrs	Female	emmawilliams5528@yahoo.com	\N	601-850-9271	\N	282 Cameron St.	Jackson	MS	39212	1600
4731748b-f353-4978-bee5-4b57b734ae56	541	538	F1600541	Forestine Ousley	Forestine	Robinson	\N	4/10/1900	121 yrs	Female	forestinerobinson@yahoo.com	\N	601-981-4793	601-454-5512	231 Valley North Blvd.	Jackson	MS	39206	1600
bb1dfb2c-9299-443d-b915-e2624842e9fd	542	540	T1600542	Thomas J.	Thomas	Robinson Jr.	\N	1/16/1969	52 yrs	Male	\N	\N	601-981-4793	\N	231 Valley North Blvd.	Jackson	MS	39206	1600
71c69ca0-e68a-444f-809c-3530203529fc	1090	1088	W16001090	Wilbert	\N	Oatis	\N	11/22/1947	73 yrs	Male	\N	\N	601-948-0043	\N	1015 Laura Ave.	Jackson	MS	39209	1600
7ac9d382-523d-44d3-9a22-277da0fb00d2	553	551	T1600553	Timothy	\N	Rush Sr.	\N	3/10/1963	58 yrs	Male	electrush@yahoo.com	\N	601-260-1152	601-954-2466	131 Marshall Drive	Jackson	MS	39212	1600
0273b9ae-53d7-4548-a31c-01c8ef29bff6	1653	1488	K16001653	Kylon	\N	Spann	\N	10/12/2002	18 yrs	Male	\N	\N	601-376-7291	\N	1710 Florence Ave.	Jackson	MS	39204	1600
b366a74c-8adb-4418-96e4-ff753746e223	567	564	C1600567	Clara Estell	Clara	Seaton	\N	1/23/1930	91 yrs	Female	clomiss@aol.com	\N	601-372-7546	\N	1752 Cranston Grove Dr.	Dickinson	TX	77539	1600
5e2f7791-bf99-444d-8d1e-0f1d56fb9f0e	568	566	V1600568	Vic	\N	Sexton	\N	11/4/1958	62 yrs	Male	vsexton@city.jackson.ms.us	\N	601-953-4160	601-953-4160	2918 Shelia Dr.	Jackson	MS	39209	1600
d48d61cc-c5b0-4f03-8c9c-fa6ae214d632	571	569	R1600571	Ruby Jean Proctor	Ruby	Shaffer	\N	9/5/1939	81 yrs	Female	\N	\N	601-353-1890	\N	524 Fredrica Ave.	Jackson	MS	39209	1600
ffc35d5d-175a-4285-9121-4edea83855af	589	13	M1600589	Mary Pope	Mary	Abron	\N	3/15/1949	72 yrs	Female	\N	\N	662-902-0353	\N	4454 Liberty Hill Rd.	Jackson	MS	39206	1600
905bdfe8-86d4-4a03-aea0-8efc65d99bb7	601	599	L1600601	Lynda	\N	Robinson	\N	4/19/1975	45 yrs	Female	l_robinson2010@yahoo.com	\N	601-906-3469	601-906-3469	231 Valley North Blvd.	Jackson	MS	39206	1600
1e2ec488-c3e4-4803-8521-21a817760477	609	606	D1600609	Doretha	\N	Smith	\N	6/22/1928	92 yrs	Female	doretha22@outlook.com	\N	601-355-4250	601-750-2240	1123 Arbor Vista Blvd.	Jackson	MS	39209	1600
edc3bb85-7704-47d7-b174-67fa5fc02c17	618	616	M1600618	Miller Bernard Jr.	Miller	Smith	\N	1/2/1900	121 yrs	Male	\N	\N	601-362-4969	\N	5914 Whitehill Dr.	Jackson	MS	39206	1600
acd69e01-4302-44f7-b840-10ce9cb03e0f	621	619	S1600621	Stanley	\N	Smith	\N	11/19/1955	65 yrs	Male	smit6129@bellsouth.net	\N	601-924-1144	601-502-6754	407 Parker Drive	Clinton	MS	39056	1600
b9a9f087-1f8d-48d5-9355-869b4b89e28f	3643	1330	K16003643	Kevon	\N	Harris	\N	2/18/2003	18 yrs	Male	\N	\N	601-622-3806	\N	4952 Brookwood Place	Jackson	MS	39272	1600
e9e4448d-c594-4afc-8f41-d7f98ffab23a	630	628	B1600630	Buford	\N	Staffney Sr.	\N	9/3/1900	120 yrs	Male	buffordstaffneysr@gmail.com	\N	601-857-8431	601-954-4028	2381 Dupree Rd.	Raymond	MS	39154	1600
3c026591-56e8-4d09-852f-31e6db3a133b	632	630	B1600632	Buford	\N	Staffney Jr.	\N	3/30/1982	39 yrs	Male	\N	\N	601-564-5371	\N	2419 Latimer Avenue	Jackson	MS	39209	1600
1099fee1-dd35-4713-8175-eafc512c1c3c	633	628	E1600633	Eric	\N	Staffney	\N	1/29/1987	34 yrs	Male	estaffney@peoplepc.com	\N	601-857-8431	601-857-8431	2381 Dupree Rd.	Raymond	MS	39154	1600
32ba9329-f865-4439-bb5c-33fde14675c8	636	634	J1600636	Janice	\N	Staffney	\N	8/4/1963	57 yrs	Female	Janicestaffney@yahoo.com	\N	601-353-5146	601-454-1656	1715 Florence Ave.	Jackson	MS	39204	1600
8ed91632-abdb-4378-a198-133542a690a0	1503	653	M16001503	Mary	\N	Terry	\N	1/13/1989	32 yrs	Female	\N	\N	601-454-0478	\N	131 South Denver St.	Jackson	MS	39209	1600
a6e1d41c-8fc1-4008-af37-5be6820239e5	1085	1083	W16001085	Winford Earl	Winford	Fisher	\N	1/8/1962	59 yrs	Male	\N	\N	601-260-8613	\N	1832 Lula Lane	Jackson	MS	39209	1600
51e70084-769f-49d5-a5ae-eb095969dce9	639	637	G1600639	Gail Renee	Gail	Gettis	\N	5/2/1956	64 yrs	Female	gailgettis@gmail.com	\N	601-982-5579	601-331-1644	2213 Queensroads Ave.	Jackson	MS	39213	1600
ff94672c-167a-4048-89f8-5013210582ee	644	642	B1600644	Brenda White	Brenda	Tate	\N	6/8/1950	70 yrs	Female	btate@jackson.K12.ms.us	\N	601-355-5232	\N	2616 Hemingway Circle	Jackson	MS	39209	1600
4193df10-928d-4994-9201-f35363aeb0e7	3637	\N	G16003637	Gabrielle	\N	Love	\N	\N	\N	Female	gabilove1314@gmail.com	\N	901-355-3904	\N	117 Elizabeth Ave.	Madison	MS	39110	1600
dc444fbd-2f86-4704-9e3f-00b73365af45	649	647	A1600649	Alphonse R, Jr.	Al	Taylor	\N	6/18/1953	67 yrs	Male	queart2@aol.com	\N	601-856-8483	601-201-1528	789 Rosewine Pointe	Madison	MS	39011	1600
ff5add99-ce54-4509-9aa8-223d0b79e0ba	1669	292	L16001669	Lanae	\N	Williams	\N	10/22/2003	17 yrs	Female	\N	\N	601-260-5563	\N	110 Ellicot Burn	Clinton	MS	39056	1600
82c05c6d-f4ee-4bf4-be0f-f33991c06853	930	537	T1600930	Trenton C.	Trenton	Robinson	\N	7/28/1983	37 yrs	Male	\N	\N	601-906-0814	\N	127 Victoria Place	Brandon	MS	39042	1600
f11bcbab-7ff6-4fcc-a86f-db27935bf11f	966	1311	T1600966	Tekisha	\N	Nash	\N	12/21/1975	45 yrs	Female	ttnash21@gmail.com	\N	601-405-1311	601-405-1311	445 Hillandale Drive	Jackson	MS	39212	1600
43b9e1e7-90eb-4512-85a7-c3ce59e89c48	654	1043	R1600654	Rilanda Terrell	Rilanda	McGill	\N	10/3/1953	67 yrs	Female	rilandamcgill@yahoo.com	\N	601-942-5040	601-942-5040	334 Summerville Drive	Madison	MS	39110	1600
91007416-f5bd-4d74-8009-f66ddf2e6795	655	653	R1600655	Ruby	\N	Terry	\N	1/4/1940	81 yrs	Female	\N	\N	601-454-7613	\N	131 South Denver St.	Jackson	MS	39209	1600
01b86fd3-4d36-4fec-bd34-e4de4dbcf951	657	653	L1600657	LaTricia Regina	Latricia	Terry	\N	3/11/1995	26 yrs	Female	\N	\N	769-233-4278	\N	131 South Denver St.	Jackson	MS	39209	1600
810dd97d-1546-4629-bd5a-45d50dd60121	691	689	C1600691	Chelsea Janai	Chelsea	Walker	\N	8/15/1990	30 yrs	Female	chelseajpace@gmail.com	\N	601-717-2304	\N	905 West Ridge Drive	Jackson	MS	39209	1600
d6cd0038-c029-470a-a85c-eaa89454174d	692	688	S1600692	Shelby Kathleen	Shelby	Walker	\N	1/19/1994	27 yrs	Female	snowflakeshelby@yahoo.com	\N	601-613-4443	\N	905 West Ridge Drive	Jackson	MS	39209	1600
5ac7b034-2a88-47e3-8c9b-0d8032de387c	1634	826	P16001634	Paul	\N	Covington III	\N	2/9/1997	24 yrs	Male	\N	\N	601-355-2239	\N	1047 Pecan Blvd.	Jackson	MS	39209	1600
3b66cb03-c231-4e4c-89c0-4d57420e4e64	718	714	M1600718	Marquisha	\N	Williams	\N	12/2/1978	42 yrs	Female	\N	\N	601-948-5374	\N	1403 Florence Ave.	Jackson	MS	39204	1600
633caa38-b8e5-412b-a84d-cf5b31f48bb0	934	465	A1600934	Artavian	\N	Washington	\N	11/11/1996	24 yrs	Male	\N	\N	601-203-9664	601-956-1228	1832 Northwood Circle	Jackson	MS	39213	1600
65b4cfaf-7378-45d8-8e11-7c4795a5faaf	720	718	J1600720	Jeraldine	\N	Watts	\N	3/30/1936	85 yrs	Female	watts.jeraldine@yahoo.com	\N	601-355-3525	601-259-9771	1454 Sullens Ave.	Jackson	MS	39213	1600
a8d75487-8897-48f6-aa81-f467a17dc78a	722	720	A1600722	Amos Eric	Amos	Watts Jr.	\N	3/1/1962	59 yrs	Male	\N	\N	601-906-7208	\N	1602 Booker St.	Jackson	MS	39204	1600
b02fe951-8adf-4bd9-ac75-838399ce5b28	728	726	M1600728	Marshall Tyrone	Marshall	Webber	\N	9/11/1961	59 yrs	Male	bluetee55@icloud.com	\N	601-594-1786	601-594-1786	1049 Matthews Avenue	Jackson	MS	39209	1600
6b9d12fd-ea8f-4930-b6df-010728e67f9b	973	972	K1600973	Kenyatta Daniell'	Kenyatta	Willis	\N	12/9/1994	26 yrs	Female	\N	\N	601-371-2709	\N	806 Eagles Nest Drive	Byram	MS	39272	1600
e5b9f54b-6495-4214-b61e-580300eaa9f0	737	735	A1600737	Audrey Bernice	Audrey	Wiley	\N	1/23/1951	70 yrs	Female	audreybwiley@yahoo.com	\N	601-982-4794	601-331-3562	1546 Countrywood Drive	Jackson	MS	39213	1600
e62e1618-966f-4411-b0c9-09b2c94cfb5f	741	739	A1600741	Alois	\N	Williams	\N	6/22/1900	120 yrs	Female	aloisw077@gmail.com	\N	601-572-4445	\N	768 Jasmine Ct.	Jackson	MS	39206	1600
7b4a248d-0454-41d7-8e65-751a07d07b82	746	744	C1600746	Clara Lavon	Clara	Williams	\N	10/15/1954	66 yrs	Female	cwilliams1024@att.net	\N	601-353-3163	601-940-2745	1024 Matthews Ave.	Jackson	MS	39209	1600
015066f6-89b3-464d-9c48-f761e0f5e6a2	787	785	G1600787	George A.	George	Woodard	\N	3/18/1944	77 yrs	Male	\N	\N	601-355-1291	\N	1917 Wingfield Circle	Jackson	MS	39209	1600
3c06dc3a-7c87-4e5a-b661-8d9ca0cc713d	789	787	L1600789	Louis P.	Louis	Wright Sr.	\N	6/11/1953	67 yrs	Male	lwright@entergy.com	\N	601-371-6687	601-946-2887	1344 Tanglewood Place	Jackson	MS	39204	1600
b9fbb74b-3901-49ab-80d5-5b187cd0700a	790	787	D1600790	Denise	\N	Wright	\N	2/25/1953	68 yrs	Female	cdw1908@gmail.com	cdw1908@hotmail.com	601-371-6687	601-260-6109	1344 Tanglewood Place	Jackson	MS	39204	1600
bcedce70-b3fc-46b5-a1f3-7ba2715ecb88	792	787	E1600792	EuShawn	\N	Wright-Smith	\N	9/16/1982	38 yrs	Female	eushawn@gmail.com	\N	601-371-6687	\N	1344 Tanglewood Place	Jackson	MS	39204	1600
598d83fe-c053-4fae-a15e-a4d9dd146964	814	902	A1600814	Anthony Jerrod	Anthony	Henderson	\N	12/23/1990	30 yrs	Male	\N	\N	769-251-1100	\N	410 Justin Cove	Byram	MS	39272	1600
af3cfee2-da2b-4fe3-856d-7e42a1577858	817	1088	N1600817	Narah	\N	Oatis	\N	6/29/1952	68 yrs	Female	narahdoatis@yahoo.com	\N	601-948-0043	\N	1015 Laura Ave.	Jackson	MS	39209	1600
0f04f020-de18-41fd-a86d-d65799337a40	828	826	P1600828	Paul E.	Paul	Covington Jr.	\N	7/23/1963	57 yrs	Male	\N	\N	601-355-2239	\N	1047 Pecan Blvd.	Jackson	MS	39209	1600
de44b7cb-babb-41f4-98d8-c6ae4bea64b3	835	833	J1600835	Jerome	\N	Beaman Sr.	\N	9/2/1961	59 yrs	Male	jeromebeamansr@yahoo.com	\N	601-922-8422	601-613-1087	321 Springfield Circle	Jackson	MS	39209	1600
fa1d20ea-0f34-4b9d-bcec-8a22ac16e35f	836	833	A1600836	Angela	\N	Beaman	\N	5/12/1960	60 yrs	Female	abeaman@bellsouth.net	\N	601-922-8422	\N	321 Springfield Circle	Jackson	MS	39209	1600
eaa20066-97c9-4116-ba11-daacc48ef95b	1292	1290	N16001292	Nathaniel	Nate	Greathree	\N	7/26/1964	56 yrs	Male	\N	\N	601-896-3511	\N	260 Pearlie Owens Dr.	Jackson	MS	39212	1600
f8843060-27cb-462d-a476-fa0d2cf04cac	874	872	C1600874	Cornell	\N	Roberts	\N	10/27/1959	61 yrs	Male	crob6@bellsouth.net	crob6@bellsouth.net	601-955-5767	\N	214 Pebble Brook Drive	Clinton	MS	39056	1600
97495587-0a4a-4df7-8c09-b88564e0cf85	875	551	L1600875	Linda	\N	Rush	\N	8/30/1964	56 yrs	Female	rushlinda86@gmail.com	\N	601-260-1152	601-260-1152	131 Marshall Drive	Jackson	MS	39212	1600
08dfad4a-f7f3-41c2-b1bc-83e1eca2d80f	883	3253	L1600883	LaTasha C.	LaTasha	Clark	\N	8/7/1975	45 yrs	Female	latashacc@gmail.com	\N	601-668-0820	\N	111 Bear Creek Ct	Canton	MS	39046	1600
61c07878-2264-4687-96de-bc8a714a9215	1552	1551	C16001552	Clay Bingham	Clay	Morris	\N	7/3/2001	19 yrs	Male	\N	\N	601-898-7740	\N	227 Lake Circle	Madison	MS	39110	1600
c7beeabc-159c-4a97-b88e-2a116672d854	1548	1546	J16001548	Jeanne	Jeane	Bryant	\N	6/16/1982	38 yrs	Female	jahnmarrie@yahoo.com	\N	601-969-0871	\N	237 Myer Ave.	Jackson	MS	39209	1600
51b5d67b-c6a1-46c5-b3f9-4a7a322865cb	1559	504	L16001559	Lauren	\N	Ousby	\N	10/28/1998	22 yrs	Female	laurenousby@gmail.com	\N	601-853-1108	601-966-9129	P.O. Box 2816	Madison	MS	39130	1600
646a3cb7-cbf5-4f38-905c-3f0d02177165	884	882	R1600884	Reginald D.	Reginald	Knight	\N	5/2/1973	47 yrs	Male	reggieknight480@gmail.com	\N	601-201-3027	601-201-3027	126 Brisco Street	Madison	MS	39110	1600
270ffd53-b345-4121-8d4c-2d111ea974c9	885	883	C1600885	Charlene Suretha	Charlene	Dixson	\N	8/12/1949	71 yrs	Female	\N	\N	601-566-8213	\N	1618 Topp Ave.	Jackson	MS	39204	1600
579654d2-8360-477c-b8a7-f310737804cd	888	886	L1600888	Lucy	\N	Walker	\N	12/28/1957	63 yrs	Female	lucywalker18@att.net	\N	601-373-6249	\N	140 Monaco Court	Jackson	MS	39204	1600
e475db50-4fce-4ea1-b64e-684a7023b764	896	484	K1600896	Kimberly	\N	Montgomery	\N	9/30/1991	29 yrs	Female	\N	\N	601-473-6265	\N	738 Cherry Stone Dr.	Clinton	MS	39056	1600
341d9b89-ebd7-4f92-a8ea-66c7d9c1ce91	899	872	M1600899	Maggie Brittany	Maggie	Roberts	\N	3/1/1990	31 yrs	Female	mroberts95@icloud.com	\N	601-955-5767	\N	214 Pebble Brook Drive	Clinton	MS	39056	1600
cdde2415-c5af-49bd-8f92-873b6063d16c	904	902	B1600904	Bob	\N	Henderson	\N	1/8/1956	65 yrs	Male	bahendoman@gmail.com	\N	769-251-1100	601-942-0047	410 Justin Cove	Byram	MS	39272	1600
cca5e2f7-9bd1-49bb-816d-63c65e59a2df	936	935	T1600936	Terra Bryant	Terra	Hall	\N	8/2/1965	55 yrs	Female	terrahall@bellsouth.net	\N	601-337-5759	\N	4279 Glenn Oak Circle	Byram	MS	39272	1600
0bb8f2e2-ec55-4c65-bf1a-8136be0314ba	967	965	K1600967	Kayla Makelle	Kayla	Day	\N	11/2/1995	25 yrs	Female	queenk.1995@gmail.com	\N	601-566-5255	\N	300 Byram Dr.\nApt. 35B	Jackson	MS	39272	1600
7cd9c43c-8d36-42e0-af73-0f5e2af5d210	974	972	S1600974	Sheila Armstrong	Sheila	Willis	\N	3/21/1965	56 yrs	Female	kw39212@yahoo.com	\N	601-371-2709	601-953-2731	806 Eagles Nest Drive	Byram	MS	39272	1600
809a78a0-2ef1-4c1e-a2e0-bdf533b37631	975	973	K1600975	Kenneth	\N	Willis	\N	8/15/1963	57 yrs	Male	\N	\N	601-371-2709	601-750-8707	806 Eagles Nest Drive	Byram	MS	39272	1600
594b7e53-9e2a-4934-9874-fd6e5a1d7d51	987	206	C1600987	Charence	\N	Higgins	\N	8/19/1994	26 yrs	Female	charence.higgins@yahoo.com	\N	601-856-5654	601-201-0595	117 Elizabeth Ave	Madison	MS	39110	1600
cbe9761a-c577-411d-b1da-f9a40a3f9f74	992	995	A1600992	Antonio D.	Antoinio	Prowell	\N	5/15/1985	35 yrs	Male	antonioiprwll@yahoo.com	\N	601-487-6682	601-918-3030	100 Cedarwood Drive	Jackson	MS	39212	1600
23875da4-e64f-4cf7-8b99-3240296899ba	993	995	L1600993	Lori	\N	Prowell	\N	5/29/1969	51 yrs	Female	lprowell6@yahoo.com	\N	601-487-6682	601-500-0878	100 Cedarwood Drive	Jackson	MS	39212	1600
c3c4a7d3-f91c-4a45-808d-ffb70d9fdfd6	1006	1005	T16001006	Terrance	\N	Hill	\N	7/31/1990	30 yrs	Male	t.time35@yahoo.com	\N	601-376-0845	\N	121 Waxwing Drive	Jackson	MS	39212	1600
b7a9267d-f21d-43a8-8ac5-8cd13f7fa93f	1017	872	B16001017	Briana	\N	Roberts	\N	9/25/1992	28 yrs	Female	brianaroberts25@yahoo.com	\N	601-955-5767	601-383-6261	214 Pebble Brook Drive	Clinton	MS	39056	1600
6d62b925-bacd-49ff-80ac-449f18ea1ea4	1022	1020	C16001022	Catrina	\N	Reeves - Hansberry	\N	6/24/1968	52 yrs	Female	reeves.catrina@gmail.com	\N	601-373-9633	601-668-9601	118 Rowan Oak Place	Terry	MS	39170	1600
3bb3a385-2505-448c-ab3d-7f6d0df8aa39	1024	1022	D16001024	Darrilyn	\N	Jenkins	\N	9/11/1989	31 yrs	Female	\N	\N	601-613-4284	\N	141 Stone Creek Drive	Madison	MS	39110	1600
c48be5bd-7179-4921-a6b0-c8a4a4f40f84	1031	1029	V16001031	Vincent K.	Vincent	McGee	\N	12/6/1959	61 yrs	Male	stheatingcooling@bellsouth.net	\N	601-373-9044	601-594-1484	5900 Seven Springs Rd.	Raymond	MS	39154	1600
b3c5b241-c29a-47a2-a014-2b678a1ee75a	1043	1042	K16001043	Kristen	\N	Melton	\N	7/27/1992	28 yrs	Female	kristenmichele2010@yahoo.com	\N	601-454-9955	\N	150 Magnolia Place Cove	Brandon	MS	39047	1600
fb4ca268-c4b9-4eb9-969d-439e5a27226e	2113	2111	E16002113	Emuel "ML"	Emuel	Tripp	\N	9/17/1951	69 yrs	Male	\N	\N	601-454-9531	\N	1545 Morehouse Avenue	Jackson	MS	39204	1600
65ca56d3-7d47-4b31-8d15-455c218bc168	1044	1042	V16001044	Vondakay	\N	Hardin	\N	9/14/1964	56 yrs	Female	vondakayhardin@yahoo.com	\N	601-454-9955	601-918-0575	150 Magnolia Place Circle	Brandon	MS	39047	1600
f73a69c7-05ff-4c38-950f-d20c083c46cc	3646	3424	A16003646	Aprel	\N	Barnes	\N	9/10/1998	22 yrs	Female	\N	\N	601-372-0487	\N	1451 Northlake Drive	Jackson	MS	39211	1600
34ac8ebe-b457-4052-bab6-bdfd4e809529	1049	1050	M16001049	Mildred Penny	Mildred	Coleman	\N	2/12/1958	63 yrs	Female	Penny6col@aol.com	\N	601-372-5477	601-927-2747	829 Creston Dr.	Byram	MS	39272	1600
ad08c515-a714-44fc-972c-c243a697dbe6	1627	2016	O16001627	Okayla	\N	Williams	\N	8/12/1993	27 yrs	Female	\N	\N	601-665-9254	\N	3266 Fleetwood Dr.	Jackson	MS	39212	1600
f3b73b0e-c148-4d1c-be2e-bef8173fd63a	1052	1050	J16001052	James	\N	Coleman	\N	8/25/1955	65 yrs	Male	jcolem01@aol.com	\N	601-372-5477	601-259-1714	829 Creston Dr.	Byram	MS	39272	1600
79134107-c89c-4375-9fbb-f513f755f994	1066	1063	A16001066	Adrena	\N	Brumfield	\N	7/6/1991	29 yrs	Female	\N	\N	601-922-4305	601-502-4299	1009 Westhaven Blvd.	Jackson	MS	39209	1600
82b64ca7-9a05-4520-9bb4-3a67ba74e733	1076	1074	J16001076	James Ivory (Paul)	James	Curry	\N	11/22/1958	62 yrs	Male	\N	\N	601-372-5745	\N	182 Lea Circle	Jackson	MS	39204	1600
1968052a-a4d9-437a-9734-3f9ac29c016b	1077	1074	J16001077	Jacquline Smotherman	Jacquline	Curry	\N	12/7/1967	53 yrs	Female	\N	\N	601-372-5745	\N	182 Lea Circle	Jackson	MS	39204	1600
a8681d6c-fde7-4908-bab6-61b4c22c0398	1078	1076	K16001078	Kelvin	\N	Hayes	\N	3/5/1967	54 yrs	Male	kelvinchayes@gmail.com	\N	601-373-7295	601-624-7582	3033 Fleetwood Dr.	Jackson	MS	39212	1600
3a9b1899-24b1-4199-8521-bcdd7210b4b7	1089	1087	J16001089	Jay Deville	Jay	Johnson	\N	9/5/1958	62 yrs	Male	\N	\N	601-940-3413	\N	5763 Kirkley Drive	Jackson	MS	39206	1600
7a6824c7-f079-448c-8cf9-704ac429fdb8	1094	1935	L16001094	Linda	\N	Bennett	\N	8/1/1957	63 yrs	Female	linda_edison@yahoo.com	\N	601-982-8467	601-503-5581	1835 T. J. Roberts Drive	Jackson	MS	39213	1600
22ee3c9a-cd2a-4e7c-b13e-865c9fa62430	1515	1513	M16001515	Mary Bernice	Mary	Barnes	\N	1/9/1951	70 yrs	Female	mbbarnes@nursing.umsed.edu	\N	601-850-8537	\N	5163 South Dr.	Jackson	MS	39209	1600
34d36af2-984f-4b8a-bdd9-7c8323825df2	1526	1524	R16001526	Rosie	\N	Davis	\N	5/20/1900	120 yrs	Female	rlburt1729@gmail.com	\N	601-421-3693	\N	601 Cedarhurst Rd.	Jackson	MS	39206	1600
695e8429-1053-4bbf-9a90-ca5098aad8b4	1095	1093	E16001095	Ebony	\N	Edison-Spann	\N	7/31/1987	33 yrs	Female	espann0731@gmail.com	\N	601-371-6766	601-506-7762	3100 Glennhaven Dr.	Byram	MS	39272	1600
a07e0a7c-577f-4a5b-b8b3-82ffda79ad80	1145	1143	C16001145	Charlotte	\N	Gordon-Galloway	\N	5/19/1974	46 yrs	Female	cgordon109@yahoo.com	\N	601-218-4924	\N	149 Odom Road	Flora	MS	39071	1600
5375200a-37ba-4778-be81-ab63ff3f4b41	1687	191	B16001687	Briunna	\N	Gleese	\N	11/20/1999	21 yrs	Female	\N	\N	601-969-3352	\N	268 Lexington Ave	Jackson	MS	39209	1600
3f31e313-da40-490f-a99d-699b97f31ad5	1167	290	J16001167	Jonathan L.	Jonathan	Coleman	\N	9/29/1993	27 yrs	Male	jonathancoleman1@hotmail.com	\N	601-201-1906	601-214-5576	5633 Dogwood Trail	Jackson	MS	39212	1600
4da33eb8-94a6-4966-b58b-ee92080786b5	1301	1299	R16001301	Rosie	\N	Honer	\N	11/3/1952	68 yrs	Female	rosiehoner@yahoo.com	\N	601-352-7044	\N	1210 Wiggins St.	Jackson	MS	39203	1600
5228b503-540c-443d-aac1-9645d030900d	1305	1303	M16001305	Michael Morgan	Michael	Hodges III	\N	11/5/1985	35 yrs	Male	\N	\N	601-291-8888	\N	100 Byram Drive, Apt 22E	Byram	MS	39272	1600
d99152cc-b09d-4412-aae7-fd6348a60389	1313	3592	K16001313	Kelvin	\N	Nash	\N	10/10/1971	49 yrs	Male	kelvin.nashii@gmail.com	\N	601-405-1311	601-918-8994	445 Hillandale Drive	Jackson	MS	39212	1600
05931d04-203b-4844-b024-c53119294e0a	1340	1338	G16001340	George	\N	Daniel	\N	4/29/1941	79 yrs	Male	danielgeorge528@gmail.com	\N	601-421-0688	601-932-9543	3458 Mahaffey Dr.	Pearl	MS	39208	1600
fdb386f0-25bd-4fef-a0b4-9aea837e76d7	1346	405	T16001346	Tewana	\N	Johnson	\N	8/22/1980	40 yrs	Female	tewanajohnso07@gmail.com	\N	(601) 750--5756	\N	313 Brookside Cove	Terry	MS	39170	1600
31e83153-fa25-4403-9c4c-2ed1d2524919	1357	1330	C16001357	Catina	\N	Myers-Harris	\N	12/26/1973	47 yrs	Female	myerscatina@yahoo.com	\N	601-622-3806	601-622-3806	4952 Brookwood Place	Byram	MS	39272	1600
8bce6067-dcf9-449a-a9a3-6b7aab78ad84	1364	1362	L16001364	Laura D. Adams	Laura	Hicks	\N	2/19/1963	58 yrs	Female	ldahicks@att.net	\N	601-371-9812	\N	6 Kee Court	Jackson	MS	39212	1600
0a237612-2ce1-4060-b560-692062cb45a5	1561	1480	J16001561	Jasmine	\N	Peoples	\N	3/6/1999	22 yrs	Female	\N	\N	601-613-1903	\N	306 Seminole Cir.	Terry	MS	39170	1600
12578cd8-2b93-47fd-8588-79491e2f1e95	1367	1365	L16001367	LaTarsha	\N	Sanders-Jones	\N	12/17/1970	50 yrs	Female	latarshasanders@yahoo.com	\N	601-278-4977	\N	568 Beasley Rd.	Jackson	MS	39209	1600
25112b45-9d3c-45ef-9758-4cfd27d39ae9	1368	1366	L16001368	LaTara	\N	Sanders	\N	2/22/2007	14 yrs	Female	latarasanders@yahoo.com	\N	601-624-9721	\N	568 Beasley Rd.	Jackson	MS	39209	1600
29d7033a-a776-4435-8175-3e053f449c34	1369	1368	S16001369	Sharon F.	Sharon	Bridges	\N	5/14/1962	58 yrs	Female	sbridges1908@gmail.com	\N	601-366-6845	\N	17 Lakewood Cove	Jackson	MS	39213	1600
6b52fd70-d962-49c0-af0e-35f1a5e29984	1370	1368	B16001370	Bernard	\N	Bridges	\N	2/16/1958	63 yrs	Male	bbridges@trustmark.com	\N	601-366-6845	\N	17 Lakewood Cove	Jackson	MS	39213	1600
501140d5-57c1-4559-8a1a-3ae55d50297e	1586	734	A16001586	Andrew	\N	Wilder	\N	1/2/1900	121 yrs	\N	\N	\N	601-927-7809	\N	6300 Old Canton Rd, Apt 14101	Jackson	MS	39211	1600
d6bd32ad-38a8-4f63-bf43-598be23437d4	1382	1380	M16001382	Mickala Shazmin	Mickala	Hodges	\N	5/31/1996	24 yrs	Female	mickalahodges14@gmail.com	\N	601-942-3027	\N	6300 Tank Road	Terry	MS	39170	1600
85e3f5bb-7d40-4416-8577-3e3da1965656	1387	1385	D16001387	Destiny Paige	Paige	Reeves	\N	7/7/1997	23 yrs	Female	\N	\N	601-919-6280	\N	413 Lee St.	Jackson	MS	39272	1600
8cd02b3f-d9fe-454a-ba50-661d9b126f4f	1395	1935	E16001395	Erica Edison	Erica	Bell	\N	2/15/1982	39 yrs	Female	\N	\N	601-982-8467	\N	1835 T. J. Roberts Drive	Jackson	MS	39213	1600
8c06cf2b-96c0-47e5-8437-ccd8bb905479	1425	473	K16001425	Kierrariel	\N	Mitchell	\N	9/23/1992	28 yrs	Female	\N	\N	601-352-1189	601-454-7723	2834 Hemingway Circle	Jackson	MS	39209	1600
2fea5764-a0a8-4f3a-a8e0-00c104fe54a6	1986	1984	J16001986	Joyce	\N	Winston	\N	\N	\N	Female	joycewinston93@gmail.com	\N	\N	601-927-0928	3133 Woodside Dr.	Jackson	MS	39212	1600
2ad6f824-e3b1-4d5d-ac81-b3e8775079b9	2179	2177	D16002179	Donovan	DeShawn	Adams	\N	9/22/1970	50 yrs	Male	\N	\N	601-927-5884	\N	5809 Orchard View	Jackson	MS	39211	1600
3324f352-4ef2-4010-8a6b-27c994d0387d	1427	1425	G16001427	Gregory Lee	Gregory	Anderson Sr.	\N	12/3/1955	65 yrs	Male	gandersonsr@hotmail.com	\N	601-421-5572	601-421-5572	1167 Rockett Dr.	Jackson	MS	39212	1600
5c04552c-d95c-44b5-b9dc-8c5ac6726fdd	1428	1425	B16001428	Bobbie Jean	Bobbie	Anderson	\N	1/14/1956	65 yrs	Female	bobbiekanderson@gmail.com	\N	601-421-5572	\N	1167 Rockett Dr.	Jackson	MS	39212	1600
ae334706-f920-41bb-b260-17621f540533	1444	1442	L16001444	Leroy Deron	Leroy	Willis	\N	12/15/1953	67 yrs	Male	bluesteele1@live.com	\N	601-954-1520	601-954-1520	5516 Ridgewood Rd.	Jackson	MS	39211	1600
1823bf94-7a8a-4eeb-a841-3a6535c383a5	1445	1443	H16001445	Hope	\N	Reeves	\N	7/22/1998	22 yrs	Female	hopereeves98@gmail.com	\N	601-919-6281	\N	118 Rowan Oak Pl.	Terry	MS	39170	1600
f08d9acd-ca47-4fd4-a421-ef5346c34e3b	1446	473	D16001446	Dajai'	\N	Mitchell	\N	8/4/1994	26 yrs	Female	\N	\N	601-352-1189	\N	2834 Hemingway Circle	Jackson	MS	39209	1600
1d6c315b-520a-43cf-a613-eb36050c0866	1480	1478	L16001480	Lemuel	\N	Clark	\N	10/20/1964	56 yrs	Male	lemuelclark325i@yahoo.com	\N	601-918-3296	601-918-3296	1710 Florence Ave.	Jackson	MS	39204	1600
c88efc78-db02-4aa5-b9a3-9fb792948ad9	1482	1480	C16001482	Calvin	\N	Peoples	\N	11/30/1962	58 yrs	Male	peoplescalvin65@yahoo.com	\N	601-421-2961	\N	306 Seminole Cir.	Terry	MS	39170	1600
73ea34be-9a65-4c06-8375-6b867d72c2d9	1484	1480	S16001484	Sandra	\N	Peoples	\N	6/25/1969	51 yrs	Female	cpeoples_jam1@comcast.net	\N	601-421-2961	\N	306 Seminole Cir.	Terry	MS	39170	1600
1503f595-6ba3-4c7b-bd83-9e029fcf1216	1485	113	K16001485	KauVonda	\N	Amos	\N	5/10/1976	44 yrs	Female	\N	\N	601-373-0379	601-506-6327	9879 Crooked Creek Blvd.	Byram	MS	39272	1600
31bd7e23-d773-4c34-a3cb-69b0865d5929	1486	1484	C16001486	Chasity S.	Chasity	Reed	\N	2/14/1976	45 yrs	Female	\N	\N	769-257-4627	\N	386 Raymond Rd.\nApt. 24A	Jackson	MS	39204	1600
c0d6b634-f9ca-480a-9d4c-2e9f7a7d3d6f	1506	1504	S16001506	Smeadie	\N	Fisher	\N	3/31/1966	55 yrs	Female	kelly9sbkfisher@gmail.com	\N	601-366-5155	\N	1056 Brodie Road	Jackson	MS	39213	1600
2540b424-2d4c-4cc3-ad9e-f3b9c7d88236	1510	1508	S16001510	Sara	\N	Williams	\N	1/3/1939	82 yrs	Female	williamsandson@bellsouth.net	\N	601-948-2084	601-940-0873	1215 Fairmont Ave.	Jackson	MS	39204	1600
b83768f0-9e6c-415b-8723-989f22414830	1520	1551	M16001520	Monica Clay	Monica	Morris	\N	1/2/1963	58 yrs	Female	lmmclay@aol.com	\N	601-898-7740	601-862-9275	227 Lake Circle	Madison	MS	39110	1600
ccf493c9-4e32-4980-8324-491ebd475a62	1656	1654	M16001656	Marlon	\N	Forbes	\N	4/24/1973	47 yrs	Male	polored73@yahoo.com	\N	601-665-8737	\N	929 Barberry Ave.	Jackson	MS	39204	1600
252295a6-09d9-474b-835c-e0543b2eabe0	1522	290	J16001522	Justin	\N	Coleman	\N	2/5/1998	23 yrs	Male	justincoleman35@gmail.com	\N	601-201-1906	601-572-7099	5633 Dogwood Trail	Jackson	MS	39212	1600
b2575897-71e7-4f9a-8621-d6cbb4bb1e12	1527	1525	C16001527	Catherine	\N	Dixon - Kelly	\N	11/5/1963	57 yrs	Female	mscat1075@gmail.com	\N	769-233-7256	601-502-7933	4643 Casablanca Dr.	Jackson	MS	39206	1600
ac59f4d8-532e-49c3-8437-64dad068379a	1531	1529	A16001531	Amber	\N	Gray	\N	10/26/1987	33 yrs	Female	ms.ambergray2003@yahoo.com	\N	973-480-9094	\N	6675 Old Canton Road\nApt.  2110	Ridgeland	MS	39157	1600
d2e9b8c6-5b35-46cc-98aa-0be98c989a99	1533	486	K16001533	KeShaun	\N	Blackmon	\N	6/5/2001	19 yrs	Male	lillunch56@icloud.com	\N	601-954-1860	601-278-2872	5104 Brookleigh Drive	Byram	MS	39272	1600
d360f8a6-bc47-4969-8c38-9b0e7082d73e	1664	113	B16001664	Breyana	\N	Minor	\N	1/27/1997	24 yrs	Female	\N	\N	601-373-0379	601-506-6327	9879 Crooked Creek Blvd.	Byram	MS	39272	1600
2a769503-315b-484c-96f8-280032a53719	1784	1782	L16001784	Lawrence	\N	Adams Jr.	\N	10/5/1973	47 yrs	Male	\N	\N	601-362-0081	\N	6183 Woodhaven Road	Jackson	MS	39206	1600
ceae6d1e-c92d-444d-b892-f8b3c7c6a6d0	1535	349	S16001535	Sarah E.	Sarah	Hamilton	\N	6/18/1993	27 yrs	Female	chocolate_pin_07@yahoo.com	\N	601-372-9856	601-896-2550	105 Glen Iris Place	Jackson	MS	39204	1600
ed4cbe6d-3374-414f-b4a2-baca717249dc	1540	1539	A16001540	Amy	\N	Johnson	\N	6/19/1978	42 yrs	Female	sherrell1978@yahoo.com	\N	601-665-3554	601-665-3554	303 Shadow Wood Dr.	Clinton	MS	39056	1600
b2948654-c449-43e2-be62-e785c5e3707d	1543	1541	J16001543	Jennifer	\N	Julious	\N	6/3/1996	24 yrs	Female	gigijen.jj@gmail.com	\N	601-371-6276	601-668-9605	214 Pearlie Owens Dr.	Jackson	MS	39212	1600
d9cdd1fe-d181-4473-90c8-944c2190ba0c	1546	443	J16001546	Jamiecia	Jamecia	Madison	\N	12/26/1999	21 yrs	Female	\N	\N	601-906-1814	\N	313 Heritage Place	Jackson	MS	39212	1600
bc0fdfc2-5add-47eb-8976-4f8e248d870f	1555	1551	M16001555	Merdith Wood	Merdith	Morris	\N	11/19/1996	24 yrs	Female	\N	\N	601-898-7740	\N	227 Lake Circle	Madison	MS	39110	1600
8a1b21ed-42cf-400a-8ece-ac6cf716d946	1556	1554	V16001556	Vondelle B.	Vondelle	Myles	\N	4/14/1942	78 yrs	Female	\N	\N	601-373-4142	601-955-7437	301 Briar Vista Dr.	Jackson	MS	39212	1600
c831a186-4d63-4d46-9ed9-df19841765de	1557	1555	M16001557	Marnika D.	Marnika	Nash	\N	3/22/1978	43 yrs	Female	mdnashot@gmail.com	\N	601-213-7482	\N	404 Violet Dr.	Madison	MS	39110	1600
a4c2f717-1870-4fd1-8663-51cbf1196a5a	1558	1556	C16001558	Charlie Mae	Charlie	Hill	\N	12/26/1949	71 yrs	Female	charlie2223@att.net	\N	601-668-5484	\N	124 Strafford St.	Jackson	MS	39209	1600
df702150-b631-4179-a4dd-0a631baf4570	1562	1480	T16001562	Timothy	\N	Peoples	\N	1/26/1996	25 yrs	Male	peoples_tim14@yahoo.com	\N	601-421-2961	601-421-2961	306 Seminole Cir.	Terry	MS	39170	1600
980987a7-f6f8-46ae-a4bf-d854ca885f58	1566	1564	I16001566	Isaiah	\N	Rush	\N	11/3/1997	23 yrs	Male	isaiahrush07@gmail.com	\N	601-941-7685	601-941-7685	131 Marshall Drive	Jackson	MS	39212	1600
f9331312-0dd5-49d5-a54b-6d88bf6f58a1	1569	653	L16001569	Lucretia Regina	Regina	Terry	\N	6/13/1964	56 yrs	Female	\N	\N	601-213-8471	\N	131 South Denver St.	Jackson	MS	39209	1600
06fe9936-e1c9-4513-b21d-8b2e09d84cbf	1577	1508	A16001577	Ashley	\N	Williams	\N	12/23/1986	34 yrs	Female	rap4food40@yahoo.com	\N	601-948-2084	769-233-4796	1215 Fairmont Ave.	Jackson	MS	39204	1600
6d922151-6c4b-49d4-9ed6-f8114f7a5edd	1578	1576	B16001578	Bernice	\N	Williams	\N	7/16/1946	74 yrs	Female	willbw@bellsouth.net	\N	601-362-0902	\N	1922 Boling St.	Jackson	MS	39209	1600
ae572726-4158-40af-8f49-9dd1af098599	1584	537	T16001584	Talbot	T.J.	Robinson Jr.	\N	2/14/1995	26 yrs	Male	trobial@hotmail.com	\N	601-906-0814	\N	127 Victoria Place	Brandon	MS	39042	1600
cc7e93a0-4833-4dd1-99b4-40895ff227e6	1587	1585	R16001587	Roger	Roger	Bridges	\N	7/15/1959	61 yrs	Male	bridgesroger@bellsouth.net	\N	601-362-0958	601-750-8957	15 Lakewood Cove	Jackson	MS	39213	1600
0db67ee8-3b43-4d22-b3f1-ee822067b9b1	1588	734	D16001588	Deidre C.	Deidre	Wilder	\N	5/17/1983	37 yrs	Female	dwilder24@yahoo.com	\N	601-927-7809	\N	110 Woodridge Drive	Flora	MS	39071	1600
0bfbf87c-a8ca-42ec-b54b-62016b720fd2	2173	2171	E16002173	Emerr	\N	Powe	\N	8/26/1961	59 yrs	Female	emerrp@ymail.com	\N	601-209-5151	\N	5126 Rivermount Drive	Byram	MS	39272	1600
f5e23b68-34b3-4cb6-b52b-8a52870a786e	1589	882	L16001589	Lillian Olivia	Lillian	Knight	\N	6/11/2000	20 yrs	Female	lilknight601@hotmail.com	\N	601-201-3027	601-259-9833	126 Brisco Street	Madison	MS	39110	1600
ba5a6c1a-dd6f-4525-b8c3-4244631eb964	1601	1029	T16001601	Tosh Barnes	Tosh	McGee	\N	1/8/1999	22 yrs	Male	\N	\N	601-373-9044	\N	5900 Seven Springs Rd.	Raymond	MS	39154	1600
6f83886c-cb98-4599-b370-6593f87a35fb	1602	139	M16001602	Milalai	\N	Walden	\N	1/7/2002	19 yrs	Female	lalai.walden@icloud.com	\N	601-383-1559	\N	5142 Nantuckett Dr.	Jackson	MS	39209	1600
00458ad4-a6bf-4090-a2fb-baa43324a120	1606	1365	D16001606	Demosthenes	\N	Jones	\N	3/12/1999	22 yrs	Male	\N	\N	601-278-4977	601-212-7844	568 Beasley Rd.	Jackson	MS	39209	1600
66e6d0de-fc00-493d-8e98-05d97df23b23	1607	1539	C16001607	Camryn	\N	Johnson	\N	4/11/2000	21 yrs	Female	camrynjohnson1738@gmail.com	\N	601-665-3554	\N	303 Shadow Wood Dr.	Clinton	MS	39056	1600
26ea5923-9b69-4044-9cab-c4c0a4239d7e	1609	342	C16001609	Crystal	\N	Green	\N	3/26/1979	42 yrs	\N	crystal267914@yahoo.com	\N	601-896-6199	601-594-5861	112 Rollingwood Drive	Jackson	MS	39211	1600
aac15510-2e8b-488d-9a47-6dc60a01d902	1618	473	J16001618	Jerry	\N	Mitchell III	\N	2/6/2002	19 yrs	Male	jerry.mitchell2602@yahoo.com	\N	601-352-1189	\N	2834 Hemingway Circle	Jackson	MS	39209	1600
c1315a4f-c2c5-4604-a48b-b24bc3ed18fa	1619	473	M16001619	Makayla J.	Makayla	Mitchell	\N	10/4/1998	22 yrs	Female	\N	\N	601-352-1189	\N	2834 Hemingway Circle	Jackson	MS	39209	1600
a24c8d12-0632-4945-9bdb-4f22007ce56f	1633	372	D16001633	DeKala	\N	Hood	\N	6/28/1998	22 yrs	Female	dekala100@gmail.com	\N	601-213-2420	\N	1448 Forbes Drive	Jackson	MS	39272	1600
9b860fe2-5397-4006-a000-5c7618b4d7eb	1639	1637	J16001639	Jeremiah	\N	Barnes	\N	7/25/1975	45 yrs	Male	jeremiahbarnes72@yahoo.com	\N	601-977-9075	601-466-4404	111 Herring Drive	Raymond	MS	39154	1600
11cab470-4f78-4cd2-9dd4-feb41ae9c392	1640	1637	L16001640	LaGrace	\N	Barnes	\N	7/1/1973	47 yrs	Female	lagrace.barnes@att.net	\N	601-977-9075	601-310-7059	111 Herring Drive	Raymond	MS	39154	1600
fee8da08-2ab3-412c-ad13-0ab49f9ae1d1	1660	1556	Z16001660	Zackeya	\N	Ward	\N	4/28/1993	27 yrs	Female	\N	\N	601-668-5484	601-668-5484	124 Strafford St.	Jackson	MS	39209	1600
567f0632-3ebd-4654-9e97-6128f5aa82be	1663	1660	B16001663	Barbara Davis	Barbara	Booker	\N	10/3/1938	82 yrs	Female	\N	\N	601-926-1866	\N	210 Lindale Cir.	Clinton	MS	39056	1600
1e0871ca-02e3-4004-a0b5-8403f13bc117	1665	1362	J16001665	Ja'Miraca	Ja'Miraca	Hicks	\N	11/6/2002	18 yrs	Female	Jamiracahicks2002@gmail.com	\N	601-371-9812	\N	6 Kee Court	Jackson	MS	39212	1600
d8c983b3-a387-495f-a5e7-88e8661582f5	1673	1671	J16001673	Jean	\N	Jacobs	\N	3/31/1955	66 yrs	Female	jjacobs@entergy.com	\N	769.300.8191	\N	63 Enclave Circle	Ridgeland	MS	39157	1600
8dd53a0d-31bd-49d2-821d-e877b5277788	1685	1484	B16001685	Brandan T.	Brandan	Tate	\N	8/16/2001	19 yrs	Male	\N	\N	769-257-4627	\N	386 Raymond Rd.\nApt. 24A	Jackson	MS	39204	1600
c7595c1f-b95b-4075-b929-0720b8e12a43	1706	1637	C16001706	Carter I.	\N	Barnes	\N	5/27/2003	17 yrs	Male	carisabar123@gmail.com	\N	601-977-9075	\N	111 Herring Drive	Raymond	MS	39154	1600
f10fec13-53de-4fa5-a911-75f23e2a008d	1707	1637	T16001707	Tobias	\N	Barnes	\N	9/28/2005	15 yrs	Male	tobjerbar123@gmail.com	\N	601-977-9075	\N	111 Herring Drive	Raymond	MS	39154	1600
e8284571-dcbf-4400-b688-364448d84280	1716	1083	T16001716	Treasure	\N	Fisher	\N	\N	\N	Female	fishertreasure@yahoo.com	\N	601-260-8613	\N	1832 Lula Lane	Jackson	MS	39209	1600
0ae9b24b-4ca4-4c8c-857f-7064a3ca3be9	1723	376	A16001723	Alexzandria	Alex	Horn	\N	11/17/1999	21 yrs	Female	\N	\N	601-750-9431	\N	3535 Highway East	Pearl	MS	39208	1600
7ed9e206-27f3-4cec-8e23-82b67aaa9e2a	1834	1832	D16001834	Deetrich	\N	Anderson	\N	9/26/1971	49 yrs	Male	deetrich1@yahoo.com	\N	601-624-7846	\N	250 Winfield St	Jackson	MS	39212	1600
0552e756-14af-4470-91b2-d47adf4ef151	1835	1833	T16001835	Teresa	\N	Edwards	\N	8/27/1965	55 yrs	Female	leedwards553@yahoo.com	\N	601-760-0665	\N	1633 Shirley Avenue	Jackson	MS	39204	1600
e498635b-bb88-4a47-8bcf-d5b576ca428a	1888	1886	J16001888	Jacqueline	\N	Lake	\N	6/8/1979	41 yrs	Female	jacquelinelake39159@gmail.com	\N	601-218-6217	\N	223 Rutherford B. Hayes Circle	Jackson	MS	39213	1600
d1e11e1e-5194-4740-8448-595e88ff9aa0	1937	1935	J16001937	James	\N	Bennett	\N	9/17/1945	75 yrs	Male	linda_edison@yahoo.com	\N	601-982-8467	601-362-5578	1835 T. J. Roberts Drive	Jackson	MS	39213	1600
6fded7dd-18ea-4913-b555-8bb340f8bf76	2004	2002	A16002004	Anthony	\N	Wilson	\N	11/26/1967	53 yrs	Male	\N	\N	601-829-0535	601.454-7169	303 La Coste Ct.	Brandon	MS	39047	1600
63f77e36-738c-4ebd-bcfa-cc18952e41bf	2017	2015	M16002017	Martha	\N	Hester	\N	9/16/1955	65 yrs	Female	marthahester80@gmail.com	\N	504-201-2383	\N	217 Cozy Ln	Cedar Hll	TX	75104	1600
de744fe3-4bd4-4ce8-b241-d83ff2f90508	2018	2016	E16002018	Erica	\N	Williams	\N	9/26/1973	47 yrs	\N	ericasapphire2@yahoo.com	\N	601-372-0907	601-609-3146	3266 Fleetwood Dr.	Jackson	MS	39212	1600
bba254f5-8757-4c4a-be9e-601cd3fb935c	2043	2041	A16002043	Asilyn	\N	Myers	\N	10/24/1994	26 yrs	Male	asilynmyers@gmail.com	\N	601-260-1205	\N	4952 Brookwood Place	Jackson	MS	39272	1600
39f0d290-52e1-4656-a333-90c6b1742c71	2066	2064	L16002066	Leon	\N	Williams	\N	3/8/1949	72 yrs	Male	wil9314@gmail.com	\N	601-982-2155	\N	2102 Queensroad Avenue	Jackson	MS	39213	1600
167cee8d-57b4-4d96-8d72-ffe873f6c858	2070	2068	J16002070	Jeanne	\N	Julious-Tate	\N	7/17/1972	48 yrs	Female	pjjtate409@yahoo.com,	jeannejtate@yahoo.com	601-373-7113	601-953-0310	409 Horseshoe Cove	Byram	MS	39272	1600
ba32c8a5-752e-4aca-8303-4e7693a911be	2072	2070	D16002072	Dorothy	\N	King	\N	1/2/1900	121 yrs	Female	dorothyking897@yahoo.com	\N	601-850-6829	\N	1230 Hill Avenue	Jackson	MS	39204	1600
26991242-050e-49f0-b073-884abcdb288f	2098	2002	J16002098	Jennifer	\N	Steele-Wilson	\N	1/7/1971	50 yrs	Female	jsteele7@comcast.net	\N	601-829-0535	601-454-7169	303 La Coste Ct.	Brandon	MS	39047	1600
974b201a-b6b8-47ee-a86a-d99ffc24814b	2102	2100	L16002102	LaVaughn	\N	Rankin	\N	3/26/1967	54 yrs	Male	lvrankin5@gmail.com	\N	601-454-4109	601-454-4109	420 Lake Dockery Dr.	Byram	MS	39272	1600
4dc9c2ce-4a0b-4aec-9e2e-4f7c961797f0	2103	2100	S16002103	Sherry	\N	Rankin	\N	5/13/1968	52 yrs	Female	slrankinaka@aim.com	\N	601-454-4109	601-918-2598	420 Lake Dockery Dr.	Byram	MS	39272	1600
2e10ba25-1c38-4a09-bbee-ff6a5e164e5c	2110	2108	M16002110	Mikey	\N	Tillman	\N	11/10/1974	46 yrs	Male	\N	\N	601-405-5803	\N	1001 Cherry Stone Circle	Clinton	MS	39056	1600
c2103216-1138-479a-9481-193d96fb48a3	2115	2113	C16002115	Cherry	\N	Price	\N	4/30/1968	52 yrs	Female	cherryprice17@yahoo.com	\N	601-813-5879	\N	1620 E. County Line Rd\nBuilding 13, Apt. i	Ridgeland	MS	39157	1600
a71967e6-a42b-4452-af35-f61fa0ffc151	2150	2166	L16002150	Lockye	\N	Lake	\N	8/31/1900	120 yrs	Female	churchfolk23@aol.com	\N	601-957-6577	908-361-9369	1829 Lake Trace Dr.	Jackson	MS	39211	1600
d0db498a-527b-416a-a39b-491b2989912d	2168	2166	S16002168	Samuel	\N	Lake	\N	6/16/1947	73 yrs	Male	lsambiggsamtwo@aol.com	\N	601-957-6577	908-868-1562	1829 Lake Trace Dr.	Jackson	MS	39211	1600
0466a5c1-0668-4fe8-85c1-447d4fd2eabc	2171	2169	T16002171	Tonya	\N	Evans	\N	4/4/1987	34 yrs	Female	tonyam1987@yahoo.com	\N	601-709-6020	\N	4308 Newpost Road	Jackson	MS	39212	1600
4e5632bd-4503-4cf8-8251-1e893a3491be	2180	2177	E16002180	Edith Michelle	Michelle	Adams	\N	8/29/1972	48 yrs	Female	edithadams/3@hotmail.com	\N	601-927-5884	\N	5809 Orchard View	Jackson	MS	39211	1600
e9837287-bc3d-46a5-a296-2f627eebc395	2181	2179	R16002181	Raymona	\N	Smith	\N	11/22/1987	33 yrs	Female	missmona2011@yahoo.com	\N	601-259-2459	\N	144 Dogwood Drive	Canton	MS	39046	1600
ae7eeb8e-45be-4eb2-835f-23a24266fcc3	3191	3189	C16003191	Carolyn	\N	Smith	\N	2/6/1954	67 yrs	Female	tip-57@att.net	\N	601.969.6516	601.497.7151	413 Fredrica Avenue	Jackson	MS	39209	1600
53e624ac-9eb5-4b3a-bcf8-85c6f010183f	3250	3249	K16003250	Kimberly	\N	Collins	\N	12/3/1978	42 yrs	Female	kkcollins1@gmail.com	\N	601-720-9767	\N	615 Walnut Grove Drive	Pearl	MS	39208	1600
97063439-a409-4c29-97f1-cdd76091c9e0	3251	3249	J16003251	Jason	\N	Collins	\N	6/10/1979	41 yrs	Male	j.collins9767@gmail.com	\N	601-720-9767	\N	615 Walnut Grove Drive	Pearl	MS	39208	1600
939385c5-56a1-4092-be47-e2a807fee85a	3257	3255	J16003257	Jamiel	\N	Taylor	\N	7/15/1964	56 yrs	Female	\N	\N	601-566-5815	\N	975 Mt. Elam Church Road	Jackson	MS	39208	1600
9719983c-143d-4b17-bc63-ea8ba600383c	3265	2064	G16003265	Gwendolyn	\N	Williams	\N	9/10/1949	71 yrs	Female	gyhwilliams@gmail.com	\N	601-982-2155	\N	2102 Queensroad Avenue	Jackson	MS	39213	1600
dba87f91-0176-4915-836a-dd38dde3fcff	3293	1365	R16003293	Rickey	\N	Jones	\N	2/12/1970	51 yrs	Male	rickey.jones07@yahoo.com	\N	601-278-4977	\N	568 Beasley Rd.	Jackson	MS	39206	1600
5717bb60-5d6d-4fcf-8272-14ff71baf880	3340	3338	B16003340	Barbara	\N	Mitchell	\N	12/31/1956	64 yrs	Female	barbaramitchell232@gmail.com	\N	601-951-8682	\N	445 Fredrica Avenue	Jackson	MS	39209	1600
0ba65567-9961-46e4-88db-5f9a662c4bb7	3341	3343	L16003341	Larenda	\N	Franklin	\N	4/4/1983	38 yrs	Female	larendab@hotmail.com	\N	601-347-9145	\N	650 Windward Lane	Richland	MS	39218	1600
33b80069-2671-4a46-8c0a-0e51ff6fde70	3364	3362	S16003364	Simmie	\N	Reed	\N	4/22/1949	71 yrs	Male	\N	\N	601-362-9638	601-832-1769	150 Needle Cove Drive	Jackson	MS	39206	1600
c8efc40a-47c6-4c29-8f43-f8968d27fe5f	3397	3395	M16003397	Margaret	\N	Baker	\N	12/3/1964	56 yrs	Female	margaretbaker888@gmail.com	\N	510-992-9110	601-316-3301	5000 Ridgewood Rd.   Apt# 1403	Jackson	MS	39211	1600
cbacc377-e8de-4747-8d25-b1e397000e59	3398	3396	A16003398	Amie	\N	Ray	\N	6/9/1982	38 yrs	Female	amieray1@yahoo.com	\N	601-454-7799	\N	155 Kristen Court	Jackson	MS	39211	1600
f3ee4cfe-b502-4a30-b081-10cc0eea313a	3426	3424	D16003426	Douglas	\N	Sanders	\N	5/4/1968	52 yrs	Male	dreshon@bellsouth.net	\N	601.372.0487	\N	1451 Northlake Drive	Jackson	MS	39211	1600
c3170086-73d6-4753-a584-ea0ed3a2130d	3427	3424	P16003427	Phyllis	\N	Sanders	\N	6/27/1964	56 yrs	Female	psanders522@yahoo.com	\N	601.372.0487	\N	1451 Northlake Drive	Jackson	MS	39211	1600
2bee3bef-3dfc-4699-b4f3-3cf7054432dd	3480	3478	R16003480	Rosie	\N	Clark	\N	10/25/1949	71 yrs	Female	rsclr1@gmail.com	\N	601-259-5766	\N	1038 Woodville Drive	Jackson	MS	39212	1600
67e6a0f2-deeb-415f-9ca8-f247d9da9d3d	3485	3483	I16003485	Indiah	\N	Stinson-Johnson	\N	\N	\N	\N	indiahs.j.96@gmail.com	\N	404-863-7194	404-863-7194	2119 Woodland Way\nApt. 6	Jackson	MS	39209	1600
3c44bb4a-79e9-41c3-8984-f2948a429ece	3495	2177	L16003495	LeAnna	\N	Adams	\N	\N	\N	Female	leannaadams31@yahoo.com	\N	601-927-5884	\N	5809 Orchard View	Jackson	MS	39211	1600
e113e9fe-f353-49cb-9e28-3336dba3c69c	3526	653	T16003526	Terria	\N	Terry	\N	1/19/1991	30 yrs	\N	terria-terry@gmail.com	\N	601-572-4618	\N	131 South Denver St.	Jackson	MS	39209	1600
eca6daf1-be7e-49c4-8fe3-17b21f752c38	3534	3532	R16003534	Ray	\N	Smith	\N	9/22/1959	61 yrs	Male	ras601@gmail.com	\N	601-941-8619	\N	122 Quail Run Drive	Madison	MS	39110	1600
f8813dd0-700c-4730-a2f1-a8a84a98785e	3552	3550	J16003552	Jada	\N	Kinloch	\N	\N	\N	Female	jadakinloch@yahoo.com	\N	\N	803-200-3891	429 Robins Egg Dr.	Columbia	SC	29229	1600
ad7cb4ba-2fa3-42ea-b298-39144a03399a	3588	3586	D16003588	Denise	\N	April	\N	4/18/1964	56 yrs	Female	april33109@att.net	\N	601-594-8301	601-594-8301	6213 Winthrop	Jackson	MS	\N	1600
ee45e534-803e-485f-a070-ee0d8599b2b3	3591	3589	A16003591	Angela	\N	Frazier Mitchell	\N	6/16/1960	60 yrs	Female	jesuslovesangie@aol.com	\N	601-942-0525	\N	1444 Shirley Ave	Jackson	MS	39204	1600
5a378dfe-054f-42e5-a776-4155ed8cb40e	3600	\N	M16003600	Michael	\N	Mitchell	\N	9/25/1998	22 yrs	Male	michaelmitchellevents@gmail.com	\N	\N	769-226-9877	1444 Shirley Ave.	Jackson	MS	39204	1600
ca811694-5599-43dc-8500-0e9825250a4d	3606	1525	P16003606	Phillip	\N	Kelly	\N	11/1/1971	49 yrs	\N	Tooney4tha@yahoo.com	\N	601-540-4774	601-540-4774	4643 Casablanca Dr.	Jackson	MS	39206	1600
2a606ad8-ac45-42c7-9345-9ae65c9edbbf	3614	\N	C16003614	Chrystalyn	\N	Branch	\N	\N	\N	\N	Chrystalynbranch4@gmail.com	\N	15012474703	\N	2520 Dorchester Dr	Little Rock	AR	72204	1600
cc0d66e4-c4b3-4e58-8c3e-dbd6b8ed19ac	3616	\N	M16003616	Maria	\N	Mayfield	\N	9/17/2003	17 yrs	Female	nissishalom41@gmail.com	\N	601-260-2276	\N	973 Watkins Place	Jackson	MS	39206	1600
e1f7197f-2ddd-4c5f-83d3-fa303acf8111	3617	\N	M16003617	Michael	\N	Mayfield	\N	11/15/1994	26 yrs	Male	mayfieldmichael13@gmail.com	\N	601-709-6224	\N	973 Watkins Place	Jackson	MS	39206	1600
de5ca284-428b-4e91-997c-eb491184c761	3619	\N	A16003619	Andrew	\N	Lewis	\N	4/30/1974	46 yrs	Male	mrandrewlewis@icloud.com	\N	\N	601-317-4130	Post Office Box 835	Raymond	MS	39154	1600
68c6a258-ee9b-4f05-a5cd-bdb1a6992323	3626	\N	A16003626	Arion	\N	Parks	\N	4/14/1999	21 yrs	Female	arionparks2017@gmail.com	\N	616-448-8565	\N	117 Elizabeth Avenue	Madison	MS	39110	1600
f4adb581-75cb-41a7-85ff-92a59b36a4df	3628	\N	A16003628	Alicia	\N	Wells	\N	11/29/1999	21 yrs	Female	alicia.wells190@gmail.com	\N	662-695-7106	\N	117 Elizabeth Avenue	Madison	MS	39110	1600
8effcfd0-6172-406f-9ca1-e0cfdee2fd38	3629	\N	D16003629	Destynee	\N	Quinney	\N	9/17/1999	21 yrs	Female	destyneequinney@gmail.com	\N	251-689-1218	\N	P. O. 17452	Jackson	MS	39217	1600
8e888a1e-6d05-49f7-a93d-f2466269fc80	3630	\N	K16003630	Kijana	\N	Roberts	\N	3/8/1998	23 yrs	Male	kijanaroberts1998@gmail.com	\N	228-13-7882	\N	1814 24th Street	Gulfport	MS	39501	1600
72819042-5a52-41b6-a107-94c1cb3e7053	3634	\N	W16003634	Willie	\N	Willis	\N	2/11/1970	51 yrs	Male	williewillis3534@gmail.com	\N	601-850-0683	\N	2109 Barrett Ave	Jackson	MS	39204	1600
f22c8011-276a-46aa-8a56-f65b9b520ecc	3636	\N	C16003636	Candace	\N	Mayfield	\N	11/20/2000	20 yrs	Female	cdmayfield15@gmail.com	\N	601-260-2276	\N	973 Watkins Pl.	Jackson	MS	39206	1600
707343b3-1c59-4837-988f-5bbb1538f4b2	3644	2113	J16003644	Jayda	\N	Lambert	\N	5/30/2016	4 yrs	Female	cherryPrice17@yahoo.com	\N	601-813-5879	601-813-5879	1620 E. County Line Rd	Ridgeland	MS	39157	1600
bac6091f-818f-48c3-81d5-91310ba3ad95	3647	3243	M16003647	Mackenzie	\N	Armstrong	\N	2/21/2006	15 yrs	Female	Sarah1002@yahoo.com	\N	601-372-1570	601-259-2513	123 Abigail Cove	Byram	MS	39272	1600
c3256dd6-6220-46d0-bb40-25ce6818e4df	3648	3243	S16003648	Sydney	\N	Armstrong	\N	10/16/2003	17 yrs	Female	shara1002@yahoo.com	\N	601-372-1570	601-259-2513	123 Abigail Cove	Byram	MS	39272	1600
034694a8-66a1-423c-b852-f8f657e4dc51	3649	3189	K16003649	Kateena	\N	Smith	\N	1/23/2005	16 yrs	Female	\N	\N	601-969-6516	601-497-7151	413 Fredrica Ave.	Jackson	MS	39209	1600
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: chmbc
--

COPY public.users (id, user_uuid, username, user_password) FROM stdin;
4	4001128e-cc9c-474c-bafb-de02606b7d48	684fe39f03758de6a882ae61fa62312b67e5b1e665928cbf3dc3d8f4f53e3562	2092213e3a2dc94a0883419dace4bda56dbe4d978650cb72c88c77e0da021fc2
\.


--
-- Name: access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chmbc
--

SELECT pg_catalog.setval('public.access_tokens_id_seq', 7, true);


--
-- Name: candidate_candidate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chmbc
--

SELECT pg_catalog.setval('public.candidate_candidate_id_seq', 13, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chmbc
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: access_tokens access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: chmbc
--

ALTER TABLE ONLY public.access_tokens
    ADD CONSTRAINT access_tokens_pkey PRIMARY KEY (id);


--
-- Name: ballot ballot_pkey; Type: CONSTRAINT; Schema: public; Owner: chmbc
--

ALTER TABLE ONLY public.ballot
    ADD CONSTRAINT ballot_pkey PRIMARY KEY (ballot_id);


--
-- Name: candidate candidate_pkey; Type: CONSTRAINT; Schema: public; Owner: chmbc
--

ALTER TABLE ONLY public.candidate
    ADD CONSTRAINT candidate_pkey PRIMARY KEY (candidate_id);


--
-- Name: roster roster_pkey; Type: CONSTRAINT; Schema: public; Owner: chmbc
--

ALTER TABLE ONLY public.roster
    ADD CONSTRAINT roster_pkey PRIMARY KEY (roster_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: chmbc
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: roster ins_roster_code; Type: TRIGGER; Schema: public; Owner: chmbc
--

CREATE TRIGGER ins_roster_code AFTER INSERT ON public.roster FOR EACH ROW EXECUTE FUNCTION public.roster_create_code();


--
-- PostgreSQL database dump complete
--

