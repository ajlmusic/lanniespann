CREATE TABLE public.p_ballot (
    ballot_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ballot_date timestamp with time zone DEFAULT now() NOT NULL,
    election_id character varying(100) NOT NULL,
    candidate_id character varying(100) NOT NULL,
    paper_ballot_id character varying(100) NOT NULL,
    ballot_response character varying(100) NOT NULL,
    PRIMARY KEY (ballot_id)
);


ALTER TABLE public.p_ballot OWNER TO chmbc;

ALTER TABLE public.p_ballot ADD UNIQUE (paper_ballot_id); 