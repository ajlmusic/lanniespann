CREATE FUNCTION lock_ballot() RETURNS TRIGGER AS $$
BEGIN
   UPDATE e_ballot SET ballot_lock_code = CONCAT(election_id,'-',candidate_id,'-', usr_id);
   RETURN NEW;
END;
$$ LANGUAGE PLPGSQL;

CREATE TRIGGER lock_ballot_trigger
  AFTER INSERT ON e_ballot
  FOR EACH ROW
  EXECUTE PROCEDURE lock_ballot();

CREATE TRIGGER check_update
  BEFORE UPDATE ON accounts
  FOR EACH ROW
  EXECUTE FUNCTION check_account_update();


CREATE FUNCTION public.roster_create_code() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
         UPDATE roster SET RosterKey = CONCAT(LEFT(FirstName,1),chmbc,UserID);
 
    RETURN NEW;
END;
$$;

CREATE TRIGGER roster_create_rosterkey_trigger
  AFTER INSERT ON roster
  FOR EACH ROW
  EXECUTE PROCEDURE roster_create_code();
