CREATE TABLE p_ballot_codes (
    id serial,
    p_ballot_code uuid DEFAULT uuid_generate_v4() NOT NULL,
    initials VARCHAR(20) NOT NULL,
    PRIMARY KEY(id)
);

