CREATE TABLE public.access_tokens (
    id serial,
    access_token TEXT UNIQUE,
    user_id TEXT,
    PRIMARY KEY (id)
)