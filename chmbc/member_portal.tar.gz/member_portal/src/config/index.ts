const config = {
    dbHost: process.env.DB,
    dbUser: process.env.DB_USER,
    dbName: process.env.DB_NAME,
    dbPass: process.env.DB_PWD,
    dbPort: Number(process.env.DB_PORT),
}

export default config;